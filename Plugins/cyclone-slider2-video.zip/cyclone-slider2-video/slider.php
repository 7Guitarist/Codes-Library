<?php if(!defined('ABSPATH')) die('Direct access denied.'); ?>

<?php

/* Get template folder */
preg_match('/wp-content(.)*/', $this->view_folder, $aios_cycleslider2video_folders);
$aios_cycleslider2video_folder = home_url() . "/" . str_replace("\\","/",$aios_cycleslider2video_folders[0]);

?>

<?php
// For description of variables go to: http://www.codefleet.net/cyclone-slider-2/#template-variables
?>
<div class="cycloneslider cycloneslider-template-video cycloneslider-width-<?php echo esc_attr( $slider_settings['width_management'] ); ?>"
    id="<?php echo esc_attr( $slider_html_id ); ?>"
    <?php echo ( 'responsive' == $slider_settings['width_management'] ) ? 'style="max-width:'.esc_attr( $slider_settings['width'] ).'px"' : ''; ?>
    <?php echo ( 'fixed' == $slider_settings['width_management'] ) ? 'style="width:'.esc_attr( $slider_settings['width'] ).'px"' : ''; ?>
    >
	<canvas width="<?php echo esc_attr( $slider_settings['width'] ) ?>" height="<?php echo esc_attr( $slider_settings['height'] ) ?>" class="canvas-holder"></canvas>
    <div class="cycloneslider-slides"
        data-cycle-allow-wrap="<?php echo esc_attr( $slider_settings['allow_wrap'] ); ?>"
        data-cycle-dynamic-height="<?php echo esc_attr( $slider_settings['dynamic_height'] ); ?>"
        data-cycle-auto-height="<?php echo esc_attr( $slider_settings['auto_height'] ); ?>"
        data-cycle-auto-height-easing="<?php echo esc_attr( $slider_settings['auto_height_easing'] ); ?>"
        data-cycle-auto-height-speed="<?php echo esc_attr( $slider_settings['auto_height_speed'] ); ?>"
        data-cycle-delay="<?php echo esc_attr( $slider_settings['delay'] ); ?>"
        data-cycle-easing="<?php echo esc_attr( $slider_settings['easing'] ); ?>"
        data-cycle-fx="<?php echo esc_attr( $slider_settings['fx'] ); ?>"
        data-cycle-hide-non-active="<?php echo esc_attr( $slider_settings['hide_non_active'] ); ?>"
        data-cycle-log="false"
        data-cycle-next="#<?php echo esc_attr( $slider_html_id ); ?> .cycloneslider-next"
        data-cycle-pager="#<?php echo esc_attr( $slider_html_id ); ?> .cycloneslider-pager"
        data-cycle-pause-on-hover="false"
        data-cycle-prev="#<?php echo esc_attr( $slider_html_id ); ?> .cycloneslider-prev"
        data-cycle-slides="&gt; div"
        data-cycle-speed="<?php echo esc_attr( $slider_settings['speed'] ); ?>"
        data-cycle-swipe="<?php echo esc_attr( $slider_settings['swipe'] ); ?>"
        data-cycle-tile-count="<?php echo esc_attr( $slider_settings['tile_count'] ); ?>"
        data-cycle-tile-delay="<?php echo esc_attr( $slider_settings['tile_delay'] ); ?>"
        data-cycle-tile-vertical="<?php echo esc_attr( $slider_settings['tile_vertical'] ); ?>"
        data-cycle-timeout="<?php echo esc_attr( $slider_settings['timeout'] ); ?>"
        >
        <?php foreach($slides as $slide): ?>
            <?php if ( 'image' == $slide['type'] ) : ?>
                <div class="cycloneslider-slide cycloneslider-slide-image" <?php echo $slide['slide_data_attributes']; ?>>
                    <?php if( 'lightbox' == $slide['link_target'] ): ?>
                        <a class="cycloneslider-caption-more magnific-pop" href="<?php echo esc_url( $slide['full_image_url'] ); ?>" alt="<?php echo $slide['img_alt'];?>">
                    <?php elseif ( '' != $slide['link'] ) : ?>
                        <?php if( '_blank' == $slide['link_target'] ): ?>
                            <a class="cycloneslider-caption-more" target="_blank" href="<?php echo esc_url( $slide['link'] );?>">
                        <?php else: ?>
                            <a class="cycloneslider-caption-more" href="<?php echo esc_url( $slide['link'] );?>">
                        <?php endif; ?>
                    <?php endif; ?>
					
					<img class="cycloneslider-img-js" 
						src="<?php echo $aios_cycleslider2video_folder . "/images/blank.gif" ?>"
						alt="<?php echo $slide['img_alt'];?>" 
						title="<?php echo $slide['img_title'];?>" 
						width="1"
						height="1"
					/>
					<canvas width="<?php echo $slider_settings['width'] ?>" height="<?php echo $slider_settings['height'] ?>" style="background-image: url(<?php echo $slide['image_url']; ?>)"></canvas>
					
					<noscript>
						<img src="<?php echo $slide['image_url']; ?>" alt="<?php echo $slide['img_alt'];?>" title="<?php echo $slide['img_title'];?>" />
                    </noscript>
					
                    <?php if( 'lightbox' == $slide['link_target'] or ('' != $slide['link']) ) : ?>
                        </a>
                    <?php endif; ?>
                    
                    <?php if(!empty($slide['title']) or !empty($slide['description'])) : ?>
                        <div class="cycloneslider-caption">
                            <div class="cycloneslider-caption-title"><?php echo wp_kses_post( $slide['title'] );?></div>
                            <div class="cycloneslider-caption-description"><?php echo wp_kses_post( $slide['description'] );?></div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif ( 'youtube' == $slide['type'] ) : ?>
                <div class="cycloneslider-slide cycloneslider-slide-custom" <?php echo $slide['slide_data_attributes']; ?>>
                    <p><?php _e('Slide type not supported.', 'cycloneslider'); ?></p>
                </div>
            <?php elseif ( 'vimeo' == $slide['type'] ) : ?>
                <div class="cycloneslider-slide cycloneslider-slide-custom" <?php echo $slide['slide_data_attributes']; ?>>
                    <p><?php _e('Slide type not supported.', 'cycloneslider'); ?></p>
                </div>
            <?php elseif ( 'video' == $slide['type'] ) : ?>
                <div class="cycloneslider-slide" <?php echo $slide['slide_data_attributes']; ?>>
                    <p><?php _e('Slide type not supported.', 'cycloneslider'); ?></p>
                </div>
            <?php elseif ( 'custom' == $slide['type'] ) : ?>
                <div class="cycloneslider-slide cycloneslider-slide-custom" <?php echo $slide['slide_data_attributes']; ?>>
                    <?php echo  $slide['custom']; ?>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    <?php if ($slider_settings['show_nav']) : ?>
    <div class="cycloneslider-pager"></div>
    <?php endif; ?>
    <?php if ($slider_settings['show_prev_next']) : ?>
    <a href="#" class="cycloneslider-prev"></a>
    <a href="#" class="cycloneslider-next"></a>
    <?php endif; ?>
</div>

<script>
	jQuery(document).ready( function() {
		
		/* Define slider function */
		
		function AIOSCycloneSliderVideoSlideshow(object, settings) {
		
			 settings = jQuery.extend({
				'slides': '>div',
				'fx': 'fade',
				'speed': 1000,
				'timeout': 4000,
				'audio': false,
				'audioButton':false
			}, settings);

			var target = jQuery(object).find(".cycloneslider-slides");
			var slides = target.find(settings.slides);
			var slideTimeout;
			var videoResumed = false;
			var autoplaySupported = false;

			function __construct() {
				
				/* Check autoplay support */
				autoplaySupported = supportsAutoplay();
				
				/* If there is only one slide */
				if (slides.length == 1) {
					
					/* Hide navigation arrows and pager */
					jQuery(object).find(".cycloneslider-prev").hide();
					jQuery(object).find(".cycloneslider-next").hide();
					jQuery(object).find(".cycloneslider-pager").hide();
					
					/* Loop video */
					jQuery(object).find("video").attr("loop","loop");
					
					if ( autoplaySupported ) {
						/* Autoplay video */
						jQuery(object).find("video").attr("autoplay","autoplay");
					}
					
				}
				
				/* Turn off preloading to save bandwidth */
				target.find("video").attr("preload", "none");

				/* Pause all videos to save bandwidth */
				target.find("video").trigger("pause");

				/* Add preloader class */
				slides.addClass("video-slide");
				
				/* Create fake play button if autoplay is unsupported */
				if ( !autoplaySupported ) {
					
					slides.find("video").each( function(i,v) {
						jQuery(v).before("<div class='play-button'></div>");
					});
					slides.addClass("paused");
					slides.find(".play-button").on("click", function(e) {
						jQuery(e.currentTarget).parent().find("video").get(0).play();
						jQuery(e.currentTarget).parent().find("video").addClass("manually-played");
					});
				}

				/* Set audio */
				if (settings.audio) {
					target.find("video").prop("muted", false);
				} else {
					target.find("video").prop("muted", true);
				}

				/* Allows inline playback */
				target.find("video").attr("playsinline", "playsinline");

				initSlideshow();

			}

			function initSlideshow() {
				
				/* Determine timeout */
				var timeout = settings.timeout;

				if (autoplaySupported || slides.length == 1) {
					timeout = 0;
				}

				/* Intialize Cycle */
				target.cycle({
					'fx': settings.fx,
					'timeout': timeout,
					'speed': settings.speed
				});

				/* Set data-posters as posters for backward compatibility */
				slides.find("video").each(function(i, v) {

					var poster = jQuery(v).attr("data-poster");
					if (poster != "") {
						jQuery(v).attr("poster", poster);
					}

				});

				/* Play video on every transition */
				target.on('cycle-before', function(event, optionHash, outgoingSlideEl, incomingSlideEl, forwardFlag) {
					
					if ( slides.length == 1 ) { return; }

					var video = jQuery(incomingSlideEl).find("video");
					var previousVideo = jQuery(outgoingSlideEl).find("video");

					video.addClass("current-video");
					previousVideo.removeClass("current-video");

					target.find("video").not(previousVideo).trigger("pause");

					/* Preload the image of the next slide */
					loadImage(jQuery(incomingSlideEl).next().find(".cycloneslider-img-js"));

					/* Load image of current slide */
					loadImage(jQuery(incomingSlideEl).find(".cycloneslider-img-js"));

					/* Rewind video if it can't be autoplayed */
					if (video.length > 0 && !autoplaySupported) {
						video[0].currentTime = 2;
					}

					/* Replay video */
					if (video.length > 0 && autoplaySupported) {

						clearTimeout(slideTimeout);

						if (isVideoReady(video)) {
							video[0].currentTime = 0;
						}

						playVideo(video);
					}
					/* If different media type, move after specified timeout */
					else {
						clearTimeout(slideTimeout);

						/* If the user intentionally disables jQuery Cycle autoplay, skip. */

						if (settings.timeout > 0) {
							slideTimeout = setTimeout(function() {
								target.cycle("next");
							}, (parseInt(settings.timeout) + parseInt(settings.speed)));
						}
					}

				});

				/* Play first video on page load */
				var firstVideo = target.children("div").eq(0).find("video");
				if (firstVideo.length > 0 && autoplaySupported) {

					/* Try preloading the image of the next slide */
					loadImage(target.children("div").eq(1).find(".cycloneslider-img-js"));

					/* Play the video */
					firstVideo.addClass("current-video");
					playVideo(firstVideo);

				}
				/* If different media type, move after specified timeout */
				else {

					/* If the first slide is an image, try preloading it and the image of the slide after it */
					loadImage(target.children("div").eq(0).find(".cycloneslider-img-js"));
					loadImage(target.children("div").eq(1).find(".cycloneslider-img-js"));

					clearTimeout(slideTimeout);

					/* If the user intentionally disables jQuery Cycle autoplay, skip. */
					if (settings.timeout > 0) {
						slideTimeout = setTimeout(function() {
							target.cycle("next");
							console.log("298");
						}, (parseInt(settings.timeout) + parseInt(settings.speed)));
					}

				}

				/* Video events */
				target.find("video").on('timeupdate', function(e) {
					
					var video = jQuery(e.currentTarget);

					if ( !autoplaySupported || slides.length == 1 ) {
						return;
					}
					var duration = video[0].duration;
					var currentTime = video[0].currentTime;
					var allowance = settings.speed / 1000;
					
					if ( ( duration - currentTime )	< allowance && video.hasClass("current-video") && isVideoReady(video) ) {
						if ( settings.timeout > 0 ) {
							target.cycle('next');	
						}
					}	

				});

				/* Pause slideshow whenever a video is played */
				target.find("video").on("play playing", function(e) {
					
					if ( autoplaySupported || ( !autoplaySupported && jQuery(e.currentTarget).hasClass("manually-played") ) ) {
						clearTimeout(slideTimeout);
						target.cycle("pause");
						jQuery(e.currentTarget).parent().removeClass("paused");
					}
					
				});

				/* Resume slideshow whenever a video has ended */
				target.find("video").on("ended pause", function(e) {
					videoResumed = true;
					target.cycle("resume");
					jQuery(e.currentTarget).parent().addClass("paused");
				});

				/* Display loader while video buffers */
				target.find("video").on('waiting', function(e) {

					var video = jQuery(e.currentTarget);
					
					/* IE Edge ignores preload="none" so check video state first even when waiting event fires */
					if ( video.get(0).readyState == 4 ) { return; }
					
					video.parents(".video-slide").addClass("buffering");

				});

				/* Hide loader when video plays */
				target.find("video").on('canplay playing', function(e) {

					var video = jQuery(e.currentTarget);
					video.parents(".video-slide").removeClass("buffering");

				});
				
				/* Set up volume button */
				setupVolumeButton();

			}
			
			function setupVolumeButton() {
				
				if ( !settings.audioButton ) { 
					return false; 
				}
				
				/* Create volume button */
				var volume = jQuery("<div class='cycloneslider-volume'></div>");
				target.append(volume);
				
				if (settings.audio) {
					volume.addClass("on");
				}
				else {
					volume.addClass("off");
				}
				
				/* Add event */
				var videos = slides.find("video");
				volume.on("click", function(e) {
					if ( volume.hasClass("on") ) {
						videos.prop("muted",true);
						jQuery(e.currentTarget)
							.addClass("off")
							.removeClass("on");
					}
					else {
						videos.prop("muted",false);
						jQuery(e.currentTarget)
							.addClass("on")
							.removeClass("off");
					}
				});
				
			}

			function playVideo(video) {
				
				/* Don't play video if autoplay is unsupported */
				if (!autoplaySupported) {
					video[0].currentTime = 0;
					return;
				}

				/* 	Set preload to auto to ensure that video plays on Mac Webkit browsers. 
					If it is set to 'none', the video doesn't play even if the 'play' event is triggered. */
				video.attr("preload", "auto");

				/* Play the video */
				video.trigger("play");

				if (isVideoReady(video)) {
					video[0].currentTime = 0;
				}

			}

			/* Test general autoplay support */
			function supportsAutoplay() {
				
				/*
				 * NOTE: A single test using data-uri could've been used. However, IE11 doesn't fully support it.
				 */
				
				/* Consider user preference */
				if ( settings.audio ) {
				
					/* Disable on all mobile operating systems */
					if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
						return false;
					}
					
					/* Use different detection method for Mac 10 Safari (https://webkit.org/blog/7734/auto-play-policy-changes-for-macos/) */
					if ( navigator.userAgent.search("Mac OS X 10") > -1 && navigator.userAgent.search("Safari/") > -1 ) {
						return false;
					}
					
					/* Use different detection method for Chrome 66 (https://developers.google.com/web/updates/2017/09/autoplay-policy-changes) */
					if ( navigator.userAgent.search("Chrome/") > -1 ) {
						
						var v = document.createElement("video");
						v.src = "data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAaRbW9vdgAAAGxtdmhkAAAAAAAAAAAAAAAAAAAD6AAAA6sAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAth0cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAABAAAAAAAAA4QAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAABHHHAAKAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAOEAAAIAAABAAAAAAJQbWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAAAoAAAAJABVxAAAAAAALWhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABWaWRlb0hhbmRsZXIAAAAB+21pbmYAAAAUdm1oZAAAAAEAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAbtzdGJsAAAAr3N0c2QAAAAAAAAAAQAAAJ9hdmMxAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAB4ACgBIAAAASAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGP//AAAAOWF2Y0MBZAAK/+EAIGdkAAqs2UvqT/wAQABtqBAICgAAAwACAAADACgeJEssAQAGaOrhcsiwAAAAEHBhc3AAAAAQAAAAGwAAABhzdHRzAAAAAAAAAAEAAAAJAAAEAAAAABRzdHNzAAAAAAAAAAEAAAABAAAASGN0dHMAAAAAAAAABwAAAAEAAAgAAAAAAQAAEAAAAAACAAAEAAAAAAEAABAAAAAAAgAABAAAAAABAAAMAAAAAAEAAAQAAAAAKHN0c2MAAAAAAAAAAgAAAAEAAAACAAAAAQAAAAIAAAABAAAAAQAAADhzdHN6AAAAAAAAAAAAAAAJAAACxQAAAAwAAAAMAAAADAAAAA4AAAAOAAAADAAAAA8AAAAMAAAAMHN0Y28AAAAAAAAACAAABsEAAAmpAAAREgAAHmsAAC4yAAA7WAAATGEAAF5QAAAC43RyYWsAAABcdGtoZAAAAAMAAAAAAAAAAAAAAAIAAAAAAAADqwAAAAAAAAAAAAAAAQEAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAACRlZHRzAAAAHGVsc3QAAAAAAAAAAQAAA5UAAAQAAAEAAAAAAlttZGlhAAAAIG1kaGQAAAAAAAAAAAAAAAAAALuAAACwAFXEAAAAAAAtaGRscgAAAAAAAAAAc291bgAAAAAAAAAAAAAAAFNvdW5kSGFuZGxlcgAAAAIGbWluZgAAABBzbWhkAAAAAAAAAAAAAAAkZGluZgAAABxkcmVmAAAAAAAAAAEAAAAMdXJsIAAAAAEAAAHKc3RibAAAAGpzdHNkAAAAAAAAAAEAAABabXA0YQAAAAAAAAABAAAAAAAAAAAAAgAQAAAAALuAAAAAAAA2ZXNkcwAAAAADgICAJQACAASAgIAXQBUAAAAABdwAAAR5GwWAgIAFEZBW5QAGgICAAQIAAAAYc3R0cwAAAAAAAAABAAAALAAABAAAAABMc3RzYwAAAAAAAAAFAAAAAQAAAAEAAAABAAAAAgAAAAUAAAABAAAABQAAAAQAAAABAAAABgAAAAUAAAABAAAACAAAAA4AAAABAAAAxHN0c3oAAAAAAAAAAAAAACwAAAAXAAAABgAAAAYAAAAGAAACBAAABUcAAAJuAAACnAAAAq4AAALFAAAC0AAAAvIAAAMNAAADLAAAA0UAAANJAAADRwAAA0AAAAM3AAADWgAAA1sAAANhAAADYAAAA2oAAAN3AAADhgAAA4UAAAOaAAADoQAAA5oAAAN8AAADhQAAA4cAAAOJAAADrAAAA5AAAAOgAAADugAAA60AAAO1AAADzAAABBUAAAX8AAAABwAAADBzdGNvAAAAAAAAAAgAAAmSAAAJtQAAER4AAB55AAAuQAAAO2QAAExwAABeXAAAAGJ1ZHRhAAAAWm1ldGEAAAAAAAAAIWhkbHIAAAAAAAAAAG1kaXJhcHBsAAAAAAAAAAAAAAAALWlsc3QAAAAlqXRvbwAAAB1kYXRhAAAAAQAAAABMYXZmNTcuMjUuMTAwAAAACGZyZWUAAImQbWRhdAAAAqwGBf//qNxF6b3m2Ui3lizYINkj7u94MjY0IC0gY29yZSAxNDggcjI3NjIgOTBhNjFlYyAtIEguMjY0L01QRUctNCBBVkMgY29kZWMgLSBDb3B5bGVmdCAyMDAzLTIwMTcgLSBodHRwOi8vd3d3LnZpZGVvbGFuLm9yZy94MjY0Lmh0bWwgLSBvcHRpb25zOiBjYWJhYz0xIHJlZj0yIGRlYmxvY2s9MTowOjAgYW5hbHlzZT0weDM6MHgxMTMgbWU9aGV4IHN1Ym1lPTYgcHN5PTEgcHN5X3JkPTEuMDA6MC4wMCBtaXhlZF9yZWY9MSBtZV9yYW5nZT0xNiBjaHJvbWFfbWU9MSB0cmVsbGlzPTEgOHg4ZGN0PTEgY3FtPTAgZGVhZHpvbmU9MjEsMTEgZmFzdF9wc2tpcD0xIGNocm9tYV9xcF9vZmZzZXQ9LTIgdGhyZWFkcz0xIGxvb2thaGVhZF90aHJlYWRzPTEgc2xpY2VkX3RocmVhZHM9MCBucj0wIGRlY2ltYXRlPTEgaW50ZXJsYWNlZD0wIGJsdXJheV9jb21wYXQ9MCBjb25zdHJhaW5lZF9pbnRyYT0wIGJmcmFtZXM9MiBiX3B5cmFtaWQ9MiBiX2FkYXB0PTEgYl9iaWFzPTAgZGlyZWN0PTEgd2VpZ2h0Yj0xIG9wZW5fZ29wPTAgd2VpZ2h0cD0xIGtleWludD0xMyBrZXlpbnRfbWluPTEgc2NlbmVjdXQ9NDAgaW50cmFfcmVmcmVzaD0wIHJjX2xvb2thaGVhZD0xMyByYz1jcmYgbWJ0cmVlPTEgY3JmPTIxLjAgcWNvbXA9MC42MCBxcG1pbj0wIHFwbWF4PTY5IHFwc3RlcD00IGlwX3JhdGlvPTEuNDAgYXE9MToxLjAwAIAAAAARZYiEABD//vet34FNwys1a78AAAAIQZojbEEP/rzeAgBMYXZjNTcuMjQuMTAyAEIgCMEYOAAAAAhBnkF4hv9+wSEQBGCMHCEQBGCMHCEQBGCMHCEZygOSR//2wAsq2wNhoEUXe8p5786vdccE+P35+3jeXupnJRQBH976FEoRVfIxtyvqN1ubHxc81gjwnMODiN2LoljSe1vxHQ/g98aBPcZttBGDZddNn0avhmtLrNa4yAifSSaDedEMFBweQTnttknLwJKjEJQ4OPKhOxgyQbcq3SdaCQn43HlzMev/9fpfvv6HxDtW1BRV2/sejtmRRwS9u+ZTAS0KgNOegwQsagATy58jaYmHu79AhM6rYPfPYpQeY3RCWZyllPZKUQecsRdPf0lLJs7er8AjW4eIMR/H+gNvXQQ+JXhdtzfECY2wCGcfP5R+YD4/MA33hjih18ePL1vzWr1lePi+Pv8fnOfGXupnJRQFAOofH/QYQo/X+J6I2YcRpy0jQnZOhTeWg6nTrf5Onv9G9fO9D4ZswsRgOpGa9JyHW+eNCTY+BkiSc8WcP4dwEmInwxDEYkheik4WZJ63HEBY0hj6Wd7dn5MhteUEOK5simeTz3BiFOrYsQnQvk7MKoHkJU8hMfPqyb4RNxpOIQfAuxPT5MJCZ07SIANMgvg/i7/PCrOONOrbw7+pvGpux/LOeZNnV39SLZLDWLdlOqmqhGWR55jlPZLbOaqql3z2KCqWUAakllUIVyHYpREHK8GpQEvj8+vxS2wlo2wvKkA2yioHzXD5bcwiGYAzHCEcSEEf4/7//cb9QrHAmXAXCpT218/XriXKizJ4+O47qvb1xm8qXUVSuhOMqIIUmk5mgJ77Q3ROJy+BE+g9QJ8t48T3GBJ5HPk8nN5fJhRd8shBpEN71Uh3DoVEyCdbKk/AfMbo3xDi3AyGMgedZMjEJ7O2ZQUTSshEvEMBJruCTt28hOIRbxDJGICr1JLJrEQnaohzTtZDsvMCGxxpDKYLjo66bZjCEMhOjiyWAjkOF81I6ndE+vdvJ9H2ZONAJBp0TJISa35fJoJQokMPpyHOebEbVkng5P3Am7Dk8riyUqQQwTp2l2JKJz7xNGZJ7/FE8HmyeSwxPSZeiwEE0CFmUQOchgtyQ4nxAhrsGRM0nGd6MQJPIVm/vSda7xwmdnkRySc+iTw2I/f+deGWRE/v86FINEo/U5fFk/AE8SohCwhDE2yEcX7j4TJguaJ9ATMrtdqJlcTcfqLACECG+IascXz+34HjjoTi3Yk+A0aTAPYbRl+/5lkS3C48VaYLHLn/Z82x35oqfz1dMOy4gijxPImUCAA/UKtROmM4tAMJcypPAjO1z5E7r/DgT42Mw5vAZBTYEixRx8qgtAzigzjunJ6CaikyCJmUTYb0PmSNci6UsifAECmsQW/JAgk4gp4U8qJixVQVMONNmCA8UmA/eulJJpx1OnL/Pez/vazHs7qRWyMnGop3XaSqBKqO7aBCpdBUMl+CYXQkinTzKXPoEG75T6Hr2I8+ySxTIig9uE0ElqTwqKAdBqmlsv4WSrCiPVTnUMId41G7FKA80+tPbNdDBd2dAV8po4dWctsrZXGwlN4gFlErzy41ARwAtKYksK1oznmF0rC7KEqWXIMRfBM55BAwkqbRYT0KBKBjhAIolRkBiJavT5lLir4pYc/fbKFvv4F5BDM8ZSJ2u+0OxwFmQFfjVd/U9eeuzqVFmvtv8dx3Ve3rre8qXUVSugQ0GyIcK40Q6ZzeXNwTMgkyKQ2e1I4jEkqdWpcGQr6chscyQ5rviG+2xDUOJ4rKzOfdJPBZ4nnNKT0N7+7MyCdHHkKcbO4J9MThSCa0k594nk8iTympJ485CfhiFSWQlziBIVSH848rJ0N6T4jcJysiSY26QUHIIsOQVlCGYypDQ5AhWg1vIJ3cmTz2OJw4hO7OJ3daT0E0nYpT4exJ1aVyKplnZIhxTW5AkY9kEGTSUdRDccDI5GgT0OanTE4BQl8pBU8i6uSgOqQdRAJ15xC5xIhxbXE8FrCSceQ4fxIhuscQsz/VSSxVJG1vGdhbzJgOTQQmdH8fpPk6Rb3789kdfreJ3YnHgagMQgEJz8STwuIJ34Fnj8YsxRszj2YtYRsSPCYGE3pk4ZBy7ED3BFfPP6neG8dVxOtw2en/sQKexCewQzTfMeTA/aPbLJPwL9J98ILaQWv85jwN2AUOGI5WL+g6p7BDw8Zrip5DfzWYcJWAYgF7cx+RtEJlE4g86NQ3ZpmlIWcWae9j436XN/7f9vIVWVoH/87BkPuvLPA4Dmq5YOtnHpmAONCOItqj0uT/YLsDmDbiBXYOQts8r1GWpy7LxS/D0dbS2FFOfN57CGzPqPAjJ7Mf+W4T3UvlVe2edf7eX/ZluG2jML9NimCjLOqRV2JKV5QiXAbou2qw8MvpJPLP2Z1UyFRYcVNmqPQt6wlqT44cc988XbbbCaXvKcISWmQsiRUdJu6glO5naWJQCNtdErVJC3MQDZvZzYJTusFRQwqoUAiqMkN4hgVynlhlEMtXE0JQSkSxEDG2wgggRMBaT21zyWk00G8iIm3Bp2kynuAAAAAIAZ5iRDf/fsAhHEt//27///4y5QhWokggAlLy7zF1q6VfFcc+fn/R6v6Qq6rYEUY+91x3+vqNnKzPqTKiZUJ3HYVUCP81CgmDkscCmstjSGjud/o2uDjFAUPBsuPCdmtjscDV4Vz/+o1kmk8m5w6dfMCM6xMObl2BBi3Ocu7t8v533OUmBzoTwz0EDOUun/eOcDENci2oAFMG0T3eXh8tZma3s18orYPLojewuFwK6451O0A23bZu66Om/hrfHkV7vqsNYrlF9egX9Fu77Njr+PSArr/x0gGOiE1il1IReCcd3o7a2uFoJznBjPVW6Ov5+HbuC830TA01bHQlysYfH7Cul3rB/pfWEzCRO0gqdGJxKf/FQgvtcKQJ7KqXCLrxXGWVW4AFAbWgUHYkg+PK6Fq7sKfEDINiKZaz9gR+0i3fdPIGcjvlfGWiD0Vyq5EkEAEpeXeXzdrrd3xXHPn5/0er+kKuq2FPzvPH3yPba7asQ2UjCCxyUqx37HNdJrEWLhkxixJ00jH2YAZExbm1odgsBAYCJ+mqhJt7GRk6OXFEksDj/HOCSnd1PD156/U2JNTqvyO3IM4YcjDftvr5h4/XfD9GNR8+zfVwJGO7e+3u+Muub1BXp6ZVvp+WvkOiuOGb1rUdXDPrz5dgAnr0HQ6/vi6XNLkJvnl5dgGAd9QAAABvVlfCzQtjj3cPLlFVx+XtiolKjqjfl3AVYSrUtwpg2gHzoCLCg3IR5qOcDv4B+uyJEZUrFNBeLxBVgR2Nk4zqiflc5NrUu+S9HfExvo3KWETfFiIgRPYK6PTSGmavvug1ZLx06tS620NBBBgNdqG7G5AHIRxP9q93///+Mu7BoUhYSqRJBABKlGsvds4qpMnHOT/2v+nP+ZGRK2IJ6B/QJGg+iYKsmNFYPJHRMgycGZRItvfg9fT4Tjgn3DE9aIsc03jPb8Xe/bCZBo1iHiNLOR7c66+NoVKFjLRLSRh9S1QxuzATwuHz2O7G28qFuA2Je83sgEbIy5VhHNqVMvABEh3YOvvCHAC8RslBdUam9gHxMKToOXqwjbVSFDxHMjIqwOX3f4P3KeKos60K7p4j4Sir0d/iZGUAAHbPvY6OT+fKcguXXru6ZisurU9Agv4ekH+L7t8ouAXxL6JFSAa/jrkAvPXT29qau15Y51PLTs51PJU73Ethw6RffJXdyxAL+OwI+Znp7eZUuyacrBoSLXmvoDV8Jb06EHf+ipGD4ne178dhK4OfyRKeAArSNlMiD3l4eGDmSiz2VcikleEJV0CVTMLEtxJQKQCA1LplUvxWeMuVFgbDMyCUSJIIAJUo1lLSVUmTjnJ/7X/Tn/MjIlbCD1Zfk8n3P2nOsQkRhMZeQkDz7sVZoVO7Inwv2mBOJ2T4N3xkkjthZOhbAHwgOx0xmNw+Ku+zeoyGySK5+wvDX2fsBAPXepQgpshyn9r7HTnIyZKZWkLCmE3Z8USeT73y7Rr4nKe21a92Hi2lZpu9ITdv8UbME52LnhbTCYbbgAD9n2sslmQ3EQQADq59lRL/fp3E6BtTqrQj/QbO/+m+R/5cZ/xHsF76ID8jZl/LAAA3P1AD7QnBmF4vV/ZGtC6OL7mJc/rfPQAAAL1rZgoe+IIGizYwKxWGZ09mTyW9uEe4VHOCsY0TRCpZdROsGq08EbIYIByHQgYNFS05s74VVRjcSUdGoZfqfvG/2hyT+LDCbbCJJ0mDD9AtoNwhHEpVPv//334y7wVToJQoghgAACUXgabv/2n8eP97yd8DkG0MjBikUy5SRTlo4gg2rPsHJoKjwpCCrL/0sgFZAESLXYavsW9UJ0TVXS57pO/5YkOl3ni7rhwWBnFwmPKvArXJWbVZRTOuLwT9nHM4+fzmtYXZIgZQckUgmxOICnym9xZeCoykeOHeYjXgY8s3XxN3oQHAlAoYybLx2GM05Qj299JziMWliQnRRiXZ3OcjV6LlVs55ykCxrTgnjG849+MPt68d/RBes9Uj04/h8J9cGl6Vi9oOqL18disDu6ZHy7I9OQB2y32hWtbkHP7ddsATmIfaVDBuc/GdJduUN6FspT6wL+nnIA6NYNo3u/z63VRvmB8wXyvlhPgtY/4oTOD8t3Uci5FTkfBWqr8eV3I3UJUKNdqrNSP6HKe5mW47RH1qs1VV1wg/HcTwh1l7Lx6LxWaFMiohW4Nh2SKvlqNVGXeByQyoJRogQgAACUXgabv/2n+tf73kUOQyyszK8ghMBZoSEecSiKlTF2ZNsRpDCXaCeRCEiUdEV8j0XM+z4OHziuQWuSHumlfs3kEU9LZue+FcZ69jq95brmsDHoMrEf693F4oo+7X48r7M1v83kALip882W/7dHcjoVc5EYRMLE0ObaCBE71c+CCYInKI8KLBw2g5AzNXR66QSJTE3xIxVj5/kbRqM5ywVeRWjX3P3jw+cgKx0sekvNzY0N+kRNRlWzfmTo87Wb8JqB3/v3tRj/GQB4Xh/h/ggAAecfEyDxEyQ9JfeOUOggsPpRny5ACAAF1n2ROKxUMRhOdpeU8R1nV4re5wcRxo9JpDS0mCtl1RsVKrtfKv8fdjbQH0V/IdNOQtLDDVNgBTIlJyKZPXzG3b6QFHLzQMoIyLObFv+0EKf2zr58sVeCEcSsu6/////jLrRmGqUSQQAAAAF5xz/7fbPn/2KlFYJsIjBk+WSkXdCkithJGhAIIIQHQJ4eESjkomERlmlS5UBbXkEoB3WP42SkF/JembC6rqvmSXWSBhHenFKeyt8Ilsdt2D0bUYKagqhYer2Hmt4Rz4KX1WHqvjSSMQ7Ng0wZQvHlE6lEcnH3HCZwg8JjbRIcBKiQJaWX/ZuCCCVGCZhjvGHMQOovaxAB5YeUvL4cgO4XHCHBQhIh8UQ6rwu1dbhkC4knZcea7ZYC7/ny9Xemacp1W6clxgABNeclvRZgCtHYK3XSd0N9faK4Lqu9176fj09PzAGvfLu1JcY8vv0Dr+v6euAa6jqj6Pn28InTMykwBx9UAArp0AdV/bSoFXMBBBlS7dXPQeT2EQubmXHpeNJqojm+NMuPaCxzUFLXevegFlDZdCeKSD+kSo5NZolU92bF3ruukJ4rXIU8ZOop2ObeK+ECMJyX70OMUBQnO5HPalMZd4HImGZlEiRCAAAGtgLzjn/2+2fP/sVKKwOitIlR2buwRAdAg7RES1JRhEQziJUE04ImmHJycKn49uEJ4SjUStovFckrQbkPTiIqWYPl5uzVP7G00Lf3yBHRVKDk4Jto9b36eMj9pVb9pj1l0z99h1uhlUeScV6cTxj6vUAYe1NJbEgnYL5WW1eCRCymI4Myy/RnLlzIWtzqmc8YyY+yq9uZg07KvT6oyydEyQZzkCceDL0n9I/RPNR1+0Bl33D4unhu22dNviiiVHiXjPIbAFcbB0SThIQAAAcipEABZG+j0uH6DAE6AAAN2c3Qlj6Vw22wC+jcdXoAAAAOpnomEyQ/WK2Ma5q8m7jlmC/I4ynq+aS6qODab6cvj+4t17cTtClxIQuO+E185cCuPVC9bhgawJeK3PXwL19dPLFeopYIOEpzpTZCc/xjRpQk4hHErvj/v///4y9wJ1IkQgAAAABfty3/7XuVxzeYPTydeiRVOJ0Z5JStY9UkZbid8NAilXgNj3qknkKMGZcVZoiUcl0noYdG5PVWJKfJBR9x4zpw5oPiVe8vHX7UQpPDt+RfK4m17is6fsNRm6jaW1RYUCqqlNqdjbHwAyavusrIjyoRY64/j92KjHKQeZ/IKc4vvyzmKSlM+PffrXaGcNuZjHLQuyBOiAOiQ1dqrIGYE6UWQ33z/sdpKMaL8cf8glo0s4SmGircwQC8eKpqWMAfXgYdUj3kaRsOnpyNCKWu+wK6C2Q52cl6HreLyNbXAB1/A04kz42vsAv0WjLdz6PV4c/X7AC+t7cCONGzqgONwgDpo4G2QABfL0w0oACsNYAbuDxbAAB9EysuIuUcbH/Q2t80+uTXdaz0CtZ0TBGbGxFvkdmRuNnNEkDdzv6jTd7EdeoILIeaHPxBAqz1ecXeJ0t+0OwM1n7on5f/jXf4s87SWI2raMu9EgSnMaJIIAAAAAX7ct/+17lcc3mC4yciaQMInTRnUdQaojFeRDXIDqk3WbGu4GKVF94yubnzH9e5a3BS5MMImMuH8Nzn9SidpAvj0qsQfaesm6ddfOUZcAi21a1jXZD5eY47iWo691qOynYvNCxr3y8xQ1EZTpAp/v3y1+0240Quf+4wjCav1jzdPK5AoaR+6faa9TvotyrlwulYMt4YjWNg9J3TSyMVJAImReauREgkUBxHxLXrbt+OM4gCJRDnLEhJqaTIsXX2e3yNC5kayWiCTuJ0v6e/w+3NefAHpknh1/ZPbv1dpcd3ykvQVt8emYqYAAAAAFblcAAK+3pAPaZ+mAAH9PbtjVD29OqWMW8GS2HlJS1I4lPC1xsnENkqi9WYqxm8OwBcnt/0T8VU5wKuHcTjL1bUxdvYjt2nUIHbmHHKq7j/XySAcwq7jSEHgsF0ujHy4AAAAKQZpmNKTBD//+vSEcTxvv2////jL3Q1SiSCAAAAAF58eM/90KKwegEcGAjCKSswreMQFIvAhbxZHN0iZ+GkuKbMiyD7YSIexakygIOikkYPgV6fvZYH9lJpgc2tUSwQMonrMOhW/RQX5sggBOS/qf0i8/uhCEUg08fNhRvWVG2RSonDOhKmflPBwcv8WNOO5p4BFHFyQgRv10fJZWLsh80d1YninkMjRCmN+tWrq4ZD5Khx0bXeRNK6dhlMaCddPG6uIj/faTqQGqhDEahhJWWWNzsAwNpFOXBJMdSJi/JyjF1cxDUXCVEWmppTN5XX9fe4OEbx4K8EJssqq6QrAYY7d1sLRMZhz4ooomtF4xv+H9OiJ/x7ucBp+H+vBUc/Nf//+H0QDfTv0Cbz5//ABz+UAMY+PZiAAAn+H7heJAB1cwB1d/1SAALQkAMDqbKZM9H55iq+MDfO0cNEITIX5ItVhocPCBpZDxRQ6oFJG2u/bTf6JpReBHPlMeEFA4D69yFW0bKjT+eck6COAaClqUKVoX0Lq7W4IGLTGXehwNzCRDkMAANbAAC8+PGf+6FFYLk+JINoEqV4jHOTBkyVucQgIIZ7Ak0wSTJUqsIAPRNcnKPZUqkJzLPhvo8+4C1sV6XbzPQXLlzoaxAXUGHaDHsbLGJdn8E29X94/ZsfjpToDX/pUD5QwiaxPvLfFkVGHv4qlK9S2HQSNmKkXj49H9GWkSnrIj+bFGHit5xHd/VwD1y7i20qNdXIiASSlYi5RGrtckHbjd9aWj1x0/puySXHyT3q34zNLH2Wrz/C9vJZtDCjhOC5E51OZXo2uLq5jFu+PaJGbLEY7Daz83U6Xh685TNQrW3QddrTDl79NfQYi9AK4/P8PiV4GnxgAAAAArXjj7JAeoAx0zAAGuD8yYIlhu9d4B/f8L6umi5Snk3zIL3EnEZDesMAwLZh3ZTi5zmEWvJyixJNiqkQ9vYknlib8ZhXxZbBRX4wxdHgf4WNgkSSgoKQTFbB5THh4hHE3TvRv///4y80R1IkQgAAAAA/H51v/1RVE5FRAJ3XkcLMJ7fSzvAt0kwWekncnEQ8OJ1deTlX6wF4bgoya3VsUgiVdw9L5MTk0e9Zkb4FvW5OilIiJXXGe/Ful1/rNUZl8m7i/7EnybPA29LsCt2j3nnYUg79+OyqOMiIkUWajOVdA1T5SRODBi0Zynofz7p7zx4olkBcnh3slXfNx8lcW6ex6fwtNT0hLKrHSlh/Etp7sMPePZL+Ac+Ydi2gDFtgmSE5zQOq1Bbj9EADazedcaeah/9fEc4qVR0sOGfHhUIdhbaGsU0LSDrlHi596NGtGdFrzsB863rs+z1PZXw+j7vopBq8IL0/RzyOp3efh6/Uaezd8iZ8vVaYvGNDxPfdAG3gO34Gc9XyMOjt2EAR8TkQAribZAArkQNYAADqOAkC9/NwNgDU0JDzDckono7WuPqKeXYCIBrXKic4P6JatEEby+xhk2hpCgaao8F7vRD/sGUbXd6GOVYwx7uxmiOiIau3XJgPsC9G2RLdHJkZ+zs7y2RkitZhrW0ZeaI5DMiSCAAAAAD8fnW//VFUTkZTJyUEQYeocbvEnC3Vm0axjyhVI2T+ZEKGhIDcTmWrFw12ySFDEehTxjmf8MSmM+Hx+DBA5VB/Xycck9NZqgPk3oUiVAHH5EWyqOp7sUmWPdl3LPW8C/m9Z0r2zkvSb/zElpqNNNqc5yzljpKXUdv5jnmL7inGViewwf2+hxqEnqtty3lHbozng5bqJNiqp0hqlOtx4g0RG/NuZNReIcoa0h9W9Yy6Gm3FWnGE4r1XmxFnLRv8NZDxwSKT86U2aTFlgWk4Ko3eEQIMxy6Cqt9VpkwyuQIoXdQMwRHI5GoXq9HD+T6oV3pXR7CFxoQYdZzlgAMuy8Xt+FrYAAABz/5tQCf/KgAAADnxQdSP+z0/MGXqhjj2TPph0ZEGH94LjMvWEf/dOG/3NigQe/XEhgSIrG0FXlAiiqn2wykcjLVbtz3B740Qwt34ZPNRWQP2+SEnFA8EUyATU9Kl2cIRxL73/////uMvdDgamRIhAAAAABxmT/2kVeJyMAUQzKSA4hLUZsnNkE5xSeJYRLmSGxw0o4UhJ5YQqYYlXgk4k+7bOBElm0SVArFv36xkWOHm+X1WJIscy7TTR+qm39/3y3fvEsQtr9/9M+SQbRnOM6C6w9IozK4d7WHuXwKfz4yvOL/pn2L8VcOynIVU0D9ZPwOTNq7O15sT8i5v2cz8h5t9nsql75fnI+TSkCL75Y45a7j3ZC7a3r5yZDL9Ivd+O1Rg7y1Z+2yMiw85u+4MN5C/oNGDgxJvwy5dJZGxslTqCldRZ4cx15JKVZr3/VMRJeJvYZ+aOcmyysgF3sBupqkIIbZ5DGJUxLzjsRbYYM2bDPc5SgOcvU77b0BTdwvZ4snhWp1k+0BzhpjVca6I885znODIuRa3wvl/ruffv9QoqvD/PJuWtQ7OXAAB563LHf6CtgBW/q9vg1oF9/DkA7uyBeh16BYRZVML54/E2DjriM3XzIBbFHoAgJissHawOQ+iVLwlZ9EkEV6Po0XvJwxDK9LHjfE3xuhALA88WBTVfHcNUmKX7U8oc7uZ4GOVO8ZeaHAlKJESQQAAAAAcZk/9pFXnPXIc5BUyu+CEsDgCA6BFPMiCI90nJTMIRnjrPeEWLIYeb9nwJNp1SD45KEkgle8SI5hCKnePQNiHuf0q05mxdNtDooIdGSsGhx6q+n+w8EtMlEhImgcRyoXpL3Tu3h79fdW9oVb/zz22UvaktjmDcGDDvLdmz6vUPpdM4MD+pmT6KY9szNrePW9pHIZ3F7ZLL6bjdS1T5lJWtYLcXokVdl4cwcttQ4uN7BpKS8uFq7mzpOC0XCMtJRqgooegaHHewO+b6tyDRcabq7oFbyTczu9iyDo/xg9jneU4+UwcPl9XkM0qwybdPTNbIhznCcV+n5yPfyPf09HRAN7b3O+va/q6/1f20AAAAADy9kWAAAAABzATncMceF7kGIq6f4lAOPFjnQb8Gn+KCSgD34y2qdabA7+5icSJkSW9JGQ1+GuAWJbmDXEXWTvXWwOwMp4y+h8DX//E3tEhgNamLAY7w8AYms44AhHE3f/8P3//4y9UV0IkggAAAAAJP/eqhUrB7MTwNUiJxPkvEbUskEbEnmY2DSyeEwOAWMm50llr5GVIJYJpCgy752BU6Aj26f+33DRDyp1LYiPP8nCIjPQUyiz1qO709N/SK7LU0SYPkZ9X7/RxBarXfWANHfFVuXo10785K2bn7fPVcH3R+SyY6XSy0OCVK+zolz+qfi1nZuDg+hf3Kn0fcNV7TsYHGXKmluX7pV7ZUccmhGS89ceZikXP/dMSgMmA725RtnZGLP7eejnLy76dAeUI7bsj2xTsh62w+jYwj2wMZCv8NJYqx19xXzNXv7HXOTFkdeqcM1PyCvD1YB/dhxPCWHqB8xUPcXkzUydOKMvAArBF2gAcjRkRARAjFBQe/1UXU0WP5vCnDU5XqPUhX62r8Px+ABrfD87JlNcb2OFmXJlXTs4Whh0m/Lhdl2PEyAAZV4EQxonmAGc9f1N1OrzgaPJwgACpuX1Haf6ByFMLplNqshRk7B3gzT+/NzzMZNysGzErXKdID4hFqPJvtTZgEZnyK5qLwHfitdKuH6Z198si3NFi89h9TLIlMqSYB9rrDsiWMmXbjGXuBOKgqETIkggAAAAAJP/eqhUrB/DJSnEoONIY3DkhNIp1RK0MhMyRC1HJtkEeH9XIwdtgEet3xMiZRHOzeOxyMoXNuVxkRK/pcdVMhP73AcqQshIoBUzh9IlQPEqanRPUNtqGZfsWCwsrg9P+365nQeBA5M5k7innxrnb65g4anBxPteDUMHlcmYNiwPFtkKsG2Bs/rv7xuPkfMntPd/IPgcleMxTUGQhk3IyuCe6Mqzv3KO2brq7lLWmOfXsluq5o+yP28NgQn5NRrlwlv8gjxRbcjRrp6yotcS5B6Vp2H4tMMindeo6f/Of2fw5fjJ5ReSSmtLw6JjrZJARqYAZXh9nz/5uR+R9h/+2ArIF4k49LyZiBsK4IxvHY4+miF44En5z/76sgAABgiAADP/gAA9PYqX0woSdF683AiF0p4e2fd5CeXPLIZSHblanu0jupK3WDhdLXYQKJzMgZ+3OpEl7VqhsarwdVABplODASw05r3aFyfJ0tfkIXxEk+q+mUEFpw79HAhHEiL/7r///Yy90N0oghAAAAAAD/5qbuqVQlOCQzmMJRg0XnieS1NQTiQLePaRLg2wJ57jhJ3VCaNMQirydaIQ4czrIcHqSpY9Dz7JwSKwT6EiCBMFEgqNWTY9jLxVxxpUA25Y4cqRtf+S5OL/CIATLkAniJNYgg/fPktjiukGq43/P1kkhHg6kx3rWfA5OHgZO/tJVkDBxkgD/abFzRvy0UbhyS+sK5HtUFG8U69fN58OnQeQiEgPusrK93zbXIYlzf2Q5dZcX8nZyj926vqjaDu+85b7GplqbMOcG6ffGQSrpBYfGoeXIvRl4c/T8Li7m72BKaS5VI7EXqNdVq6tYw1fg8RUIcmCSM7mkNIQFow6o9Ey/NaipX1dlKGXTOrX1PT0cCBev8r42gPH8LSrutm6Sr2V1XA0O80QMfA9uQqvjwMe2k7LQ8H1eypY8nla/UXAABu43I2A4+wAdOXiZSMganK+lwQAAtpCN8j0ubsY4jx4Ym9EJy5c1c/vlQ/VIoPauAHhLxzmT+Ke1T2YO5S6lNrFsposqGN2LqLiVXRpLcJWgef8IlMkYVMVKaS4zneO5xSrR6+rBGXx1ohQiEAAAAAAf/NTd1SbG5CFW2TzOLJzMyQPYIX+Mks7ia6vVjwQkzGEOvdAJyq5LVXbuB2SQAMjkw5BukDj+EIRaROgiZj5OhyiD2EgMd0A7kJQYn/5mLya6BEiKtMlFh0TL0HZH5hBc4lJNYgSIByYOtlfbKJN5He+cMFfLyvCyiCsE9AXSegxbumDOqfrf2bKH6Gp57/Vz1R0A/ic6fbMv8W6IsDGcOnuVQSsKUwXvh6Gn3qeHfwH3GmOStb+E8W5tz9xX0xqPI0xsbgf50xQ5NcsTHdbxAqsv83Omvshh77/e9S/GIoEputqh9/a7CjWRZvfgGzxqcW/9UDDU9PnvFT1s/j7fwv0qArAAM89/W2Dfo8XgbYuts+j1+q73wNMAAAAAKwamzq7AAAAAHTlwwAAAA5n8G6vSc/9OZ2UsgCxlAfKl9yD1bd4x3VxC+AF74HZjvHkDCdVLLR1fascGg43Y+jT3EVlWd2xN8ZSPn1McOhenJ7umccaYha9l+vv53ruWIVToQ4AAAACkGehEURLDf/fsEhHEjPc7D///4y+QOUIghAAAAAAD/5qNyVWx5UTxeBIavCE+n3SUnEE8The6ieBrkgRyN3Ckx7YjG1xOJhSSGY4IBORNJs8kmEd5ABSUUPuxCBV6eIiJUR7pi/TCAUT4D1eWQfhahDOot7e3Sk3hkmSpOtE4J7rDPhVP/QRBRqdvAvTuMqBnkZcHYEmm+3+WU74L+d1jd5p+STY3PPcecM2TDB7EHMWUSACP6m9ca/2/DuePKs7C+5W4SsB5ptume7cP3DMez5Hkbobf6leG8oVkuy9qfHtyNen+DbkpDLeK6qynn3W+/NDKmH/PbD8my1ujMFU3/ZzZjQVK0w6FOtFiN7uVabvs7jV8GbUoFQsjPou4hxHOXUho/F3CQuYJUFVXuZn8m8ZznLsQ/qsavtMta2cjdyfV/Mamt3ADnfbNbvpE+l5SK0hlGUwHV8nQ40gABpdDsBq7ABq4ebzADW0+gAAHIndQ6GV+ovyk1rCvKAhZAJ1npXo31oOvXLTVCPowS5+/VDqVr02L8Dd/yRgRDst8dkHtgqZVXPpneyt4lfw1tMmiOkGjBmM49i8cVWqYyOIaYy90JzmNEEIAAAAAAf/NRuSq2CT0E3MI7rYkYOZx9kSWW5uS4DjSdyUR5HPI0MdRWYI6GGSlkuptRC+cIKik4WElkdqBnzBE9M+n7qLd7M8kIUbKtGTTkzSplKQMHTWr+ptTZq49+vfB2IQlXu5MzP0WQh9uywoiV9Ajx4Xb9K10PAi5y8LP5O1bJrQvMEUJDVLJNu/sK+e/lqAJOw/ZLJwAalqze08O7kI+HycT7Lxd1Il/G8JnznTjKQN4/9dq7Hb3FdzbzbO37K/EXWWRqojCkszfmujN0a5xcUAOPiQY2jDwlPY49B/0WgHd0ewnIj7WcAoVJ7PXU9+anqVhyCqACQgEdKGpzEWec+jb9X7/V7fhbAbvLmAXyvvDp4W7kyOrwDfuz4Wzk8TaAAAAADh+D5PLf3/CAAAB4P0IAAMe7274Xdf+EeJjEF+4GGnRopiIdn3bOi+IN1OJaYPpw9SwNVfE0BhdyWACVYAgRo05Tq6QR31CtkIrdWOJbc1+cyg2c7HwhVt7QaM3T7uQVP8CEcT7/32f/9/jL7AnSwkMQQAAAAAEr/1XzbLrBnUpCBaJl4GSwJyGpukJ0kisFbSSe35oQo8AJZbEEicMybgSWXq/ZSEgpDPTKnn1vBoEJIC6Kl88kqMfIBsgimZVqMJBB8/j8GVTTOj+BIuQmet7EtMegcxEsCIimZUy//2fy53aSrPJgLUYLbnMmM+m8xzqJ2c5f2bsFu7IJbfVbkH744lGD83bzu0n6nVP9J2a25hrAetdLQejvX61P3bndFYA5I5PyJ3/rS289VfcvVWXHVyK7Z48qrUPg9LcX15kvUPrvSn29gp914p765MYUBWUqnD+WvSJdIGQ6ehj5xHVzaY4yjA6lSzxBXJA8iQxcAADNXcjZtnUzXOc56vsiCYL5sdypx0uGjBNfcuzKxKV3zqnIdXyOp8aDL0cauzlfF4YNb43Wejke88DSAABeppV4HAgPfgB1GmBn28AC+jaricwCuxsABprzzMLuYyJsAgDiRoTExFSEJD18is0QwNVOPYpEoV57/TfXmQUyf3tM6Q+yeZHXi9Fq0evMmFExAHg3kZB4L/LxZ2g9mnNCjtDSjjwwaBgQrmxTGXuBuUSIoAAAAABK/9VVbLrB0KQmOIGpkIGiI0Y5ChZJcRwRPDBI8WyNTZUhJ4YTi2CYo2P4pIcsmVZOw4itFZwpSC3JWs8rYO/IJeY+LP3+puFB9MiVsc/Y9HgYNx9QUC3t6oRUFEIy9tj0D07dcZBfs/AXQ1P1plUHYXp95el4Mb4N784k1VFj2peNN+E8WuH71T2asIoMFM2xN0Q6qyxnDPV1JrAXoW2U16ssdI5/kGeZri2aIBmc3THA331H/PkbkWae91TZOI8VFXDTemP9tnviJNSttSetT4jxTf8beOou4ld3aK0+pjJKKoycv2/io70SAdxbLkWXMTbsCUjrsdcTSuY6jOc1/JIBfU+h2NWsuuDqYC+t1dDLrvVYAAAAABfF9V1PZVMwAAAAHl4dTd2/jHkAEfKeu3Zl+XFv4osA6+hR00VeKvq6jTxUrfior1Yna3r5oDs0PQU5saewWKugBEualhgo1WiNHDJCBlEOKfJ1nbkDOC4slgtljU+TIO1whHE//77v///4y+ugxIoAAAAAAf/NKFXsZAh1HhyWY1BHvGrI7rgZHljCS6JMLyWrzJLCRidyCSzuRI8TeQp467VkDKJ74ZGVbJx0EBHISsF7Toz1fAZXP5E8W0IOArJQTkI7SDoJECZXLP8SJ/xp+SROCGT+HOsOtp+zrtB1zgKCAlbv0ppv0+ow4FhsXqMJEJPsWQwaQ5h8F1Ts763SE/BqMOBDdv6bPOb5MLXIeX+iNq6n8oqmyPsPyJMLuMZGivGn02Bc212G8dXfSnYI19Tx5kXdGw+N5UDM4b9qqMY1v2bxykucNEyBGpQIJhZ/+ddhoNHYGX3kAA2DK1LwRiWnkGVLQDkOfMiRydAAA2OZLvaA/G9V+wOw+/+NwRq8aS+Phxq8KTi8jx+PrcKfjyHF5uJ9/Z1Hp9AdHCAx73okr9bCAArx5DLYei7Xj8QvjSAOqkDHtOogAflaQ/KAAXoedUL6voAhdJT2kwLo91dzKiyNDiRnkY0sfL5IrwTBfmP5g5gynp4VLWec0bcO53spPfoJs7YXUszbreVDm2SlsICRaJzEddBm+SJt5SERnFqtGX5yiREkEAAAAAAf/NKFXsfRkpMGx3E9K8hOqELfJiWPzZHF3SNBBPU5MirWEeCaslnw2tNJ1qdajt1mdK39/8AQfPl/GfB52FbxrHFjjt3SWAOm/AR1GLuahC0BHsj5jJo8AF8+TRBImgft7DsQFlW6mxk1ySM+D1sD6vyCkow6CzuMnAXobyoghJJgiYSdN3QEvRXZuwviey9uSFlCn3bNJw47D6Y9oImP9ef2L+Z8exHJOr2iSPWOnptv2YblncVW73iWTBtF9Dl1VmuEOCj6QVYK50rG1jN/7XHmyXXesSuSYXDE1mqH5E3YvAAgcTnndOkIO5ToFvS1HE5bVGzc/3KKa34sstjCY3zamws0Ab+CAG/R7PaND5YAPR9p4fh6uwAAAAALw3cPRxAAAAAHa9XefAmhq3/vl2gFt9xfynJe5wlHuQjrjoUg2YDNU0MgtWeMctobZeX3ZV4ZD6POF8i9ukz5edQA0sA7rT/IqdMCW+pi9+R49rLMJPbAggSp4IRxM3dv9//7+MvsqQbBQwAAAAAB/34upkqr2MnoJW9WTx6SHA+nEeEYoljZ5DHwSEiiR49tpNOQ5wMhVhEdC3IEChRkEqJYjEEE46szkJAyAtYTRDuasjEVlogJI7iTYf2km2bPpP8uTCkBppy3Rfbp0UQKPsCdDyowm4H5UkIHRlvLJlPkEfKn7nHg59aTqs+b+OyozLPVe48o9/5Xkc7kopazFLo/jsHHTGte1qa6ml6VKw7cF6RMf5NysV7WiO3hQT0HKf2q8+8HNV76m2ktDHXO4K+yjGzpn4ujpVK+qTpJY9rzVDdf68yjbO/JBU3G4r4cXKOTidk4igbQADLCDYxTjPTCtvMSdUd03pdXLBTbYGtWHwtb+k8vv2GfsXquAcjyFGPwn17voBHxn7fw74m0BxOadl1MR0HQbAHH62BV6vdwAZaWvKuhtfyO+PIhfTgL26AKx+Zd10wG/hcCTDuPLkG3oelwZsOJv00UcTP4Z/t1YEuAJ+cT/O3NzJbEFxP1vU8/MSwQjRsh63siq/gMRpK0Y5ObLed64nDPoj750+dyG5fCHKyZj26t8caCzgOD4aBxxGXqQHOu1xMqHPCzNMQzwecrGXuByUSIkggAAAAAH/fi63cqr2MskYRCe+kEOp+MiPKs2TR0MhWzNT7IjWaTy/DyXANmQdvyeehEMrdyHFIogk6kYjLAShTqIGSNhPt+EyrImdHpfxf2DKwicaCQMihBkI46wmERJI4ifWJuhvFuZVkjAaQo0tZYMuiDRpUMv/lxHnPUJAgf+P3uYvsLXb8EhDidpbetcN1xyTFEBmzJl/KdugqI+ssIM54+WpXjWkmliuoVoLJAFpHH4+nN6xR9bvkbMV60hRIYvBfIIxjr9rEJ52XWhrRDt7KUCc/L1W1VfGL8EzL61m3kMiRSyYXNnpqxxZMgWwPDyvZtdruRuc5el2pFSh4bVnfhvlYKR8VLOE51zkkf4ZPha+G2fc4AAbOENbopAN3gOy+5+Z64AAAAAGtwC7AAAALZr1M0Y+38gtTcpZhb5emI4wMu46yvxTKecLqAk41EaASlYQKUpaYiGU7LTu0GhsjXv1OPdnZhnDwleaskFjUAdV58Hu9CBzN44yJ7Cn2ULd2NBjUKOAAAACAGepUQ3/37BIRxNOfd0///+MvdDdKHIYAAAAABx/5CrymAgGORkctJ4vwuR5vwAlQzpHQ8ToRpLKOJ8N50T4L4IJ6eLgcQhrcuQi427oJGREJ8mvEq+etxlAuJQdbZ+AqBGBi/V1iyiFVma70EcUrBwkSGIQYWmuOqk6rs3i6ZZfalrhtKkTYblCzYHzuasgMgXjedAxlJtYlKu/9q9gmn+T8j9SyfBJnqkpU+ZofUdV5g6/oeXB7Q707tIFi2V50SAT27+XPOUqkCTJCtZlZDlE/GLHYe8fQeLe62xvKNPq/5a8sda0vvmHlf/JKosdbApN3cbRv5znyC0xOwKQkWL/O/btQZuqEUus8o+H36ieJNu2VQe4OafNMHhnMTtk26ZpTAfn1044Sk6WV1IR7CWYtOo9TASJKwhBM4XXn/K9hAbup/8uv7aZ8fnAAbuw++1+Pwwvp8wHT12GpsAVyL1Jbus4a+Dw/QhXoO3kB2Owy6w8bt+NtAavVcKDyPCkABy9faDjZul+5nb4GAiAc25VfADHJSWFTqQcSh8VIy4eYCDIBUYPOKphRqOeq+yGW79gm5nOzhy4evnpOiqJHXGS28AF5kotMiFUpHi0f6y2U5hQIy9yGhOUyIchgAAAAAHH/kKvKYO3I7J4fyQR8t95luERdkifOsgS5lwQhS7eSkY/Kkgnl7JKvUI6ybnWHKJCdLgZLF5EhxEVRRCYlStLJgASTD7E+2y6Dl+b8qr0baCSD0d+dwepzKP9Pd64jkyGQuZshoUYFE88yqigBSismEePB9Vz+EkN8zhdifmzpywyZH5g0TWMAnBLgJvUM+9gY5+KlkdAo8x/AZJ0V27HsiWR1f7daTMhBJzTehcw0i7NOuHQ3Sf1v7usQfeug928T5Q1Xl3yy3g7c+E3vSD685h3DnR3L1jEFNbFb4eH5o6HoU9iA9x7qh7jjX+E6Ssiu0+uSB1zgy2qpLb8TrI8eIFFFFEFGWwXv5azkIjwREAcflbG/hbAAA6OPo9VwpAAAeJwAAC+SV4MgAAeB/0AAC4hxHftD+xC+WENXMvG7JIOA7DUMdGlof0bS0lc4NuSl95uUlBWHcVRhfQw3ptXNNZIl9GlrVan69DKtlNWBkcMCJ1VlAaZcLfMXFYk8YWOCEcT06//////jL3RHQigAAAAAB/80q8VMBNoSV3hBDuHZiWXqkYkiZcRY3DSPH+mkYVEnl84TRwnisiGoQl2CZZRMVsi1pN2Xn5OCgJwRE4AMnQSMfAT4fK6SbFZaqVZIkaiJhMsCv7UCQKKUYRMQCEOBem9ZQp3VAJT4pB0777j8lvyZPf5Lb4dvZBRa6CZn0SP5PmjaHFPtOXf1/2SihfN8mD90zKXgGzfu2I4MIi9tjjtEBMgLk+p2zd4cYRMckZv6X8NGwADN0vqdB6pdka8y8bzjRjc6ot0+yXI3z+i6b0niHEZu17fHn0d2E674o1PE+N8fN90i/VPvVHqe/IRX9g16mksoliVgVXrtFc8yeMK/U62J3ofi+bVXDBV66KTxsVFx2laJFETlRf+Z1rJoxRRRRZlnOJ9FGr9v/P38gcf0cE/G+pyOnrAYdZqbA1fB2dhYByuRoG7wtpu+n2GgJ996KAAcfzQvseAAXxPQQZfC2QAA6dTUAhLId5PJK+JBOa8pqwIU/QmwIK+yiAeDvySYVfTmscUqXKEAlQJ+4AGyDgDoxFJrKDnydNOk27Y7DyPwO9Aq7GQJMrALtfI+mzOXlSrIJ0NeOyiXRRl7obpRJBAAAAAAH/zSrxUwMiYY+VKxFaybr1R4QnvLZLLbKfOEkbsQjzvn5PL8DI6jPEOHUSRE6iqbGEqNnAB52ETwFwnwqFU82IkzF9NkwXy92kJTJxBBsrJ4RNuAo6tj0QWZQYzjcmUkoyiD4mdQ3vWYbrWTqx6ybG7vyuHXpMpqLH7t35niTEkhG+pcaEUM9s2JmDXf1endi9jfnvICAQdrZnfvYMjeTZx1nJhiYGYGA49wHPcmAkHEdAeUfWEJyw4e3elKcnmeOn+3d2bftmN31BpBzH9IzDeNbAzbXi+EuGFwXOxplFFcL1NS78F2vW+WOC5AhHDJmlgEaZzbeTPR80skSsTMTookJAxOWl6pYP2a1zoFdBiAMfoyj83MAAMsssgAACvD5gAZpcuVZAAAAAAMvV8wAAAB+MANnQIdh90Ex5mayARbX245V93pVelNyjqq9qo6lJYjNAz2CMAD5Am0oent8gK78td2ugp2qJYbfBM7Hto6neLqd7PtNnFIOLoIU1i/5sSdQyS8AhHE3ge/v///4y+0NzokQgAAAAAD/5xeGMGAGIJpEulwSHmBRPmM8hE62TpwbehEdFRyDyIlo7pOvyEhwnPkNPNIPhk1sJ0KhHM3KFgVOwmGKSmMIiRb12tjk6Cur7qFJ5JPxFYnIpHsMg4vFxJzcMzsai39P1pNJKmEdPAyYz/h/ORReJKuWOXy3Bx9YEYNr9Z1fZpM3tne5AzdW7F5jIxKBMBvp8b/XvyHJJABrw0KL/CxbUAnsek9k9MkwLJFiTPVqeBbTg0/mteno+1g49LPoPyH8OWhR9S0rjjbUF1nzLWQdlPG8XBQwNRKOE+T8vLXX6NquNxt+1V7bwOtwV+007XvIFk6KKwbaW9RumdkhwnPYfhM3QeynXRrjNAWCrtWyIoMHbujv8QOnCCtzeFRzOloZFTYpcUUUR2CsD7pACPr7JTHxIWRZFEDiYbV4exz+xxxgMu2+LYGp5YAvXz6nYA7PqOH3kDk+wgAVoYxoQ6nEA3dZxZVyPB6zYABePp+aANfcvuPHKnpVudqo64oxR1dSOgGmaouiwBV5P9FfDgAFFRxl5a0Q2I54QDLzolUwJV0+m7x/v05CmNtRrpBUisqUWBOVXFRTXS139dykF6XlrQjL3QzIoRIhxGAAAAAAP/nF4YwdLkRSSef5gR2NaTSkA6MkvAkInASMqmQfxQnvOEEszqsmzCd23RMuUNkR4Tjplg4Momq0TR1IhmN3PhLtXeFe/0yYE2IqzYUItE9Ev39J0EjHm2iOIaKt8JMsXKlYjSNYx7eRnZcpssXO5fw/WzrsAgpWPgaa5tfJIKsmi27fP5GXmZxw/knFpA+DQQrDvMK5J+UqEXrWWr6qUBEYt/kmImWdm4Gd6/I8y07rrwPRpb8hNojvHv37ptPkjiVsq8AHw3GM8LxdrkuPDlgn1N1jyX+fokOiJcDhk3vyvO85TwOVe9lYdhtmqyjVx3p93vh9SkAV+NB9DCAPD5EhRWJc4gMoEMkoBBHxBmj0rEA/McP/5/VsYB0UBfn7F8/o9P/P5aAAAl/AAAF5w89CUIVrDj5S4cYmDhUF4uWV0MqiVWtDtM61X/g0QUoZ105EDqX8j3x3E53Oc3N4K2JYnw9S0ebawtMumPjFOOXK2XcJIv8elhknT+XAhHE7duv////4y/gdCKAAAAAAH/vdFSpsE0HoK9nTmxHtc4h0bkJLF+BCM/JkIoCfLLpFfOSO1NdPGCe8ztbA4VhEhbclkhUSSSTsYjA1lqagiMxIwrNsW+SgySmUig7s3MQXjiLw//vi/XZFTsN1pnVNcSieU0BOIuiC5PBylJ8Woatni2J3daZLoaTw8PH8wg80rwCIE5MSTvrrFHsHeBKc2spPtd6ScLYt6ysD7Ht3jygRd2ftcx7KgyalCMCDOs4kUvpjcj6bboB8VufKGTQfP2cF9eq0nhFAA7hkCMdIc0Z90O2UMcxxbL23at5Oz3yXod46aR0rJgbLusG8MjckrbC0nQAxSYGUQO9lRF3wPZtHRI/BdtFbG2lgADJkx43Gw1DFmde38sDRRUNGjsYmG6EPgA4MnJI9M/44x6z6EU3df2sM/J/7dR/i+/19+iwBapC+Xl6sBv5UgrBqcHvez4MDh8GABl2vUf/nabKyAGX33vifPodjYADf1FwENyvevNN2AlwWT6Efk+SLKtsBKfjVWJmfjk6QPEVzf37ajmna9xHi4c9wCJZRcpPRYTjNwwrlBhxJGNJhMl0o0nnnM17JqOPvT2uwrLMVi0+S5njL3QpMJGEhyCAAAA1sAD/3uipU2Nc5Mnk7t8jnVksJy7JmjIWpBLLZ4loODkr/RSd3lBDK7onQkEbsQkWcQrziHFVEMbSs1u66iy5PZQpbBKMHllP9vn4hE8khSwPaRIN/65XlpQCEaR/e7ytIuwa5syZDotVqHrMmDs5jJU2UWHvOxwb8rg2Cnk9FTn8ikInCHXJ0HBK2WRmtmPBwJ9HfNY7jEmlmGYnlnL8f2+mTwb0+JywRRNJGaTWx5VxGuN/zeSd62cDiisQfjcFjERh8D0PJFup7Jtj2SQvJuR+7Xb9xe+XXDcfrzkbN7IIjsnZNmk5Y1Nl2LtSoqFp2OuLuxB/yRJxbLzHRV6zUJnUQkRSQMFfg6DkfvXR+b+OYAAAAAA6rGO6uF1Xj/NyABUZgALxb+5a/rPZeOkAAAAAVqoo4WSsUKCE4EMWwJ2rQCLxEgaCK6rkPuCjlHjOAPB8uzv4+HzANaZQE7waPtE2dNJ4Peg1NIB4duxWGDDaWOrrCdHXtNQb0xfu0BS2HgS+iW2BKqbqeAIRxI/f/9/f/+Mv4JLYTEiSCAAAAADW9df5tWcVkwELGYI6jAE9LxEh4WKStaElzDqZGrhCNvgpDMYojyvjJLlHNiGZzRDC5UkoGQomCQ6A1hElHHo7vbgsojKddgiMPIdI9gXasggeDCI070tLJXRSpA8v13dsgi0ZAJpUg0ADWWQcSSNifZ8nI5Zk+gQMifFffYAeJgrksXg6yBE85fN9aOmK6DdZCQwExOrcUzi9327bdjp8ykjcnHU2+b1vWPorx7+gxR6Qjm3b/34QTheI+fpVgkRlsYPLHrf/g6fui1n6bdikFlrpFiocUiVbZgHJZU1dOYMtycP1m5t35qKZdu8q1KzvD85t96AANPoGXXjL6jcZbpxnpBvYTuJwbYtXw2iwAAAANQvGhejL9xKJOhmtlgaKdkRuQ+5FwAzuRE/YSrZZX0X43jKshcZOL4roOx7j691gM9MF58zjdTpyCPG5g6vQjL4bi68DHi6IAGo3X6hGq4AAAAAAMvRcP9l/sWID874pxGxGS7qhSqa2Ce/HGqJ/XuMptPxvWImgw36O7DhpLQUZ2GJiw/lh7oOxpBjOk6CAunTV+nacz0i5ytmu0d3NDYjf+oZmOxAUsws8blbi4JRHziMvxicQlRJBAAAAABreuv82rOKyYCFnIEOBEJcr4uQ8DZQhdrEcHHIcEoEdDrCG04Dg3WSWuz5HghyWX2OCTKytkEUibNqSJUJ4GkQlyrcwxLVHlZedK36f//3vdRN+ECxJ9Fgoct9s/TicSRYpv6lAE5Fk2NPlUhpKmVBWKpiuhpKGWskZ/r7sbJ0MlHDqLKP2/JdvCx5D9Ay9XD7tTLZ+nOeeNWC3w+l0ObjKVAdD3eHnPNelc1fV9xcWkDmsUs+OlwRyA5cf81ffxswUzybhtRBmzdqXzn8jzZM5PPYhIsxayU83IJx5JrY9ZOUpiUZ4q2k7IqYGkuxvQviW0IjbR48vcejRn+hbuYn7mGvthor6QGgAAYmTFgAI3Mtw3R02v1YaDgAE/0+/iAlqeB1GXytTrfb6+QAvx/db+74cgD+GAAAAAAKKQTqjK/RGAP8SnuLPrvW2Yhnb7KZvaCpBd/KnQeqcLEMZg09TW3gBarI6t51/pCsv82KZL2tW3G260ERYi3x6MDDOe1X8m3hWyQ+K8cWhL6MSVIf4AAAAALQZqoNKTCiYb//rkhHE+/+9v///4y+SlFiEAAAAAH/P/H/qq8lJTBLi7u40Tbx6teIkN9LIT8sQs4klExBPlnSa26KTT49IRYRLSVCWggkmAwTFEcdmSFvFyvK9XyBSlgOTAkWAtYhM4cfQLSLkw2QKmZuRrEV7XweVlYAUgEnt/BKGETCO0JVSu7hvHugjEFbyus3J/fIx6nbu47L1VkMudppNYM00CK0YeaiAHEhGuWNty8wyoHjXK6MnnqI2zpnBMTY6NzCht8xGCAkQRNsDsN7W1tzrcczKF0/ZLZyzRucspZ8xfp76H9RXnmEMb1X9yvpfI/M3x2mudc09aMzscWDzRLw7cF1Zw7CzQAJFspyOdGxnxnvOGpvR8Ok+U8D3T5fQAON6nfwvrHzvz3o/omQy+j7/VvD8Evi8XZ9Nlmw7H/Ebc6wvML4/3fgeV+R8b5nRBz+MCOs1dXxncMAcj806SAw+m4nA+6+E4Tm7Jgkwms9Tn86/Z/0/xfsOBAA7UuE8h6rRBTk5AOEQnQYicj0byyo12dJZS5f1tHz8LDTVERctEjKxaLDkWrGU43A8pe9gDc6+prvI1dJUeDiAdPDh1NNmdCcmyzJbr86tCAnpiym/BHHVb2I97ubjowu0Yy80VyCNFEIAAAAAH/P/H/qq8lJTB5PP1whnNgRxGnIcNwPC5whsaJLV5Ynx3Lk5GmIcZy5HXTCXBp5E1wmLKkCMzo8nNyVCj6QJx8LZysrAJur2aqVjYKHAwT3U8+xUElH6f2kTETIEf03ZP57oL9bKoaJvEQsvlRIoCQwsOzxz6O7BcnbZ/WqzG84ymjK0cmR9EmushATshSMeps4HKnacdzKL+P9o7Z8BydD8+UtJ8M3t87lQhBg5mkcIcmcPZLw519qijTkW+MwXSHpMZ1WF2J3B6x/w0n8t+Q5IgM7w7b5Hy9TnHDWawO2rWLUn/k820BhmuxWsvleMEa5p5SWVkkUtgtnj+v1s0H2xWeiGABFFFFEjf45VRcP6CDCsZIkh7zYvl8uS/1fR5+v95oQAArU6v7z9HV1e4+j8P30gAr7Lie/AACO4XygBjLsO1ChTuJiTb9QR0WEQwaYszMINcDvJ8+on/R9diTzDcZ/TDzJ3iEYLZ1g6VdIaUP2plG81dgBthSg/odEO6GNrUCBRJ7RqvNQf07n53qWb925jM9NSJOp6x053EsX2tNcCEcTp/b3//v7jL9JzEiSCAAAAAD/f/X4f7JMJWwRXyUjxPiRMG/IYNhPuHgAinmRDRuIQ+SEua8CI8040Q7Dza0Ohk9K4kBpONAJXkk4UgiPaXdg62bg0GxMfZgCU9lZAysMiNXMfDCdOgQMO7zEAKqU11wSeCwcpCqU35OVgVKegEkMJDIziz+GxxTMQhABwsImMX1+tFEAYWxLekxs39bZUYQFKIPZxwxNRSVZpEEAmgHJEceK/iaDDmKgxc+1jOqEUqg43jl6b2UPnMnRCbTYE6Z0qWFI84xrmLNP5Gowc8dfbbtmu4duaO6REuazTIxDKfmkb5JZQGRn64I/qwTGb+y5m6zV936Kbi8xAkQchgR6jq91jPV+RMxdGKHMdHKrGMkOFAYgSFAAIeMcUsvUrc42GQnEmhfn/rHe/0nxvTBt/a/VtCNb0v0n0SZ7L8RQanzzj+3fbe5aQDHEGXH+Gxj5/sCvRP636LmGT3To+7/3vQju+pjnheTMpNXfF/xvovsHBAAJgD/z8fE857iU1exn/3aIOycnIB3kD9Y0TXNjmvvXU7fDHekerXRufzvrzkr0yoyU97OKByBa0RV1eKAc8w7JERcDpnyoILttqX0GQJ6V8BU4yrqAMlUgjL9IzMhyGAAAAAD/f/X43/1SYc8bHlhBSSW05GQ69kyN+iQ0HIiLoJK/UzpjCdaZgfKCPZ9SSh40lqC26Ws2E7ESg5f60iIJEs4mgBMoSI8nzlK7cfIzqy33EaRaBPQICJzz8PARE5x6hD9srBPYH2kgHD3ZW+1W+W6SEh3iM/C9V5plkGn890C6GEAH+T59IFsE6CpfRKIiD4crutxfedEm5szhvG625UD8PKK6xkz3UJ/s8HRwJqICNaRyUyGSAV2ODoT5vUssBb+JUGAgAnlSjr7VG5OC5ZhvG6XOyOUXPlOepG0Byjsc3Bkk4IU90jWosZRAaKZyDRWMagtlFIg2EvmN77hdkRC8U7n+DkOY3E+aSpY7CcvmgAABqVYSOnxVXhSnSBg09fZbm/O+8UXy/SGv9p8BAABxvXeJqdJ5TpvauLsAEtL9KAACGcAE+2/5ABL/wMHD3RVcsZtQuVi6udA1ftn9klS+qa+HVuV2F0iD7eGsZ0ypWYwqIfRzT4I/JBwiethzCID2U805/vSRkX46mwwLWAk2s8FrXMsHC29FpchHEyl//8///4y/hkVhUiGUKDAAAAAB+Pyn/uqZLmbFDdJJbXlJPlfNCHWOREovRyLufE0MIYPIEe5ckIdv8PEu5QyGsETHDJZKSTkmJiz0z60nq8nQW15GIBzJHIEy8RhmIhFLQCSYJAJyI12bFoaPb8ma4Mir5duk4IpTH0xNeHEsFWI67GedyePsKupRIp5ajc7yoPpiz6JC3MmKtQtfuJJEHJ8TLmpP6BCGghTkZUHx7zsd+8k0O5i3lZgrvDj8Xb/fm/6a0Dq6553m4/LQ5LeFumycl6PyzqC5rfFqmcaQvtfhDZjCawX7h7pQ4BmC5LmtjLyFyVZ418zH8TcpkIufcktCysT2fl9pHUtzdw0df+Qv74eMZcBIOyIO4cd0IW0AQ7FeybKtm27hppAJp05HAEEA6F4DmXczYXKhwSHzQVZ6F2O3M5GAAGjvd4cyjga5pCv47O+ml4ADYm4PjXSe4/6T+6cMABWHF61q9LkFQrjbDj5YABgjmhXU+S1QT7AAC1dHt58gAAt6egANbNQa6jTGJv1gRoN0TxIBbpA2tup5rtdvOKsYtOU9iDK+dAqQKzlRd6E9XKM+Sj5arLljFROLmT0TNtgIR0vN1z83OlDNSpny0KyVPZnfhnxDsE2K3wZx6oBXQd4y/SMSKJEkEAAAAAH4/Kf+6pkuZsf0GGocUT7rLJ0NmS4RfJ0bmQ8mS5FzIh1bEkORdjJTuak+I8qIa64Ruz6HyBCphCeQRM1qzHV3fJYmvboCMGNRU77D7bXY/1xOBE5zJttS6LOwK1B8fvTny4ehbTfPmfJzyUQitQce1GC64/yFKqdzEDhJNsX+GcfcKGoodvQbvi8UToMg2Tb8jIIcR0vqG+nHUQf1hAILsU8fkXxHDh3HbNFhwBMnL5n0xl63x6+kmb3bm+N7EDRYqapPlL7whUp4c9AgmUE37Z4If1VmmQgjnmphVa/vMdPrPVn3L13O4azJB2yIptLpjnUP8DZfQ7CdzPmt0X+Gdny2a1A6kmmwtFNan0aqCYwAAxBcCpSsS5lsFZfpRp3d5Ha5PmYHJ8zGp7T9NAABq9Ln925mlyfIbAAADb9/loAAAXrUK9X8bAADy/cUkupMu18o8aHMXa4UnzQjoNtioeZfHb9ne8Aftxbn1xFmOd435epiuuelN1aK5yXmZetwSPjmkudrz9caod02haTaUqmT0mWKzaMXxgfqC4DCYj8IRxPtPv/f//+MvtCkLnRIhAAAAAB8f4/8P/eKlZbYI4u+RwvEiatCQ7rpCPAMsSn2OOBJcWVZ/SSfdM6S4bwbBsWT32rJ56WTQjOuqJZKOSVFJYxWTlkilyqafwEoCCEU/OxMV74XjgiDMRgzKiwfZsnFz0QYyX4RNZSL0ESlIIUQTlyeRnXWG3I1uBICoeN1GCgzz6DksjL1RGgRwYiRKQgEhICyFAV82qCggEn4C7ZBAYsw+S3aWVykRorJNuB8nJQI30jtXJoLmk8Ql0nqKMRcO7hEmHsc3SMQj89X9pDrBNsfx9LTwy23vKQ5bJ8TFsgF0Giy8E/Qm7/t0K/W/Pw729j41pvYh/dHUHPV9S2XmTEq+bvL6D4bR0QpPXzNz93dUfrI/x3ojdHAfK7LdSLPdX69nOIX/SFMaWefF7wrNsWCfQ9fym18lOkCbJwnA8+JFFEG6uMMy/wZTb4771DxvBF+F7j8H7z0fsfA0sAAHx/ScGQBu8L8ihX7+fhfP/9vefn8vPl8vTkAI1rqcaqLvNhOuFYc2XG5cgHH5cG/nV2cS1CTlv2liJJJerAqA0M93IRg0DUynYh4PdCwkxUsUYk62tlPXo864z0ghkFyoXr1jnYYG28yjuHr7W0wnq4dSS/S0nRbx+dU/fLivqrHYujL86USQQAAAAAfH+P/D/3ipWW2PqRMuVwfkBHX4IjybfkOK8bJ7bHE8J0chwPakPBvhIiLdE8HjyGcuT9SI4iuTx8snXxksWanBURyU6GT45j8y1NKJwS8i/HSeGsxkEy93kTVPsVeZ3HUJMDNy/LY8z2ieuAEbrs2Z0lEAmIGxxI0LP/Tv5GukVEsiCh0l3DM4s1/I1BY9Y77ILgTPJ+gogW4PGZ6YajISUKpCbwJrW/tDOzHHN0H5u6g7a+l+oN6Qs7o0JkiYW7v2fDfAzdrCOYrc19slp48+lUUrEOa+kFLIrZHXIVxsQp4IXo/zGQMENUIvYUS1myEaN9LdO8/uhbmg3YMZRpeGi+lHC+cT1cfviOlZRcJYAAADe2XzHveqund0ZjFAA3eFIAdV6XtQAAYeo8bl9X8/aAAAAAueNwTk+eQAATcTULxqV1xA8XxvVzWl1/OAAGrB1nG+ikCwoci1GMHxsuWBiY4UFdwC3VeYC1wPOO6FTasYS8DmDiqaKzHBJdQ35XG0vWzkviSWeeS8b8g29178YEAzrTPDOF+dhR+NnCrvEQRLwhHE93P/l///4y/gkVhcqCYKGIIAAAAAHx7v/WtVRU2CO+x5PjUYllTkeXXyWV4QS3mMIdCkENVw+0t8R4lwHIWzJaHtJHrGfJaaiRknJ4DgBC1giEjBEpb7rbgJsgYnH4LpztpR8miJGgbK/Kk6ekIxoErQaAnysDIUkmSh5jrgmQREYJ2OTkUpfy/PUyk7uycfIUQiglphqc/8Mhdw+P5VkIO+XTEyLC0ODRmVFkyoIihWKf8y49L26Sh1WbE6s2vaLaAM/nn2BH0BYoc6U8eE/oEKC8eByqfy62779P364Zv3l+Yv8jpnmu1ADzE3yahkBpooXrVg6RmGrNnWx0/mD8Jv/Ywp3E3BS3GVpp8q9LlhDpw2yYL4a+FV0oZzs2Bx/1S6vwVPaj646u1WhdMiwBajKOYD4wjmoMi5KiijCtFZf6Yi0kvkoBtnyXmyRhlQDYXYVVMcOpHVls/F/ZbsArqPy7g+6dbAAAABd4bBc3u8sAAAA1upgb/sMo+L+rqe+l8T0FAABWpyMc5AV4HWcf1XM5UgHF5pMcjlSULOJabebpilozLeusPZ3KKrQR5xJX2zCS6n9AJKOI+DUlhpTm9ngFcpPLNmoKzG3PPLOWynRFKSBW4kq4SVgwKDy1dwJ6KVA0GkesI9e7YtZ2cSEZfhE4xEwRCiSCAAAAAB8e7/1rVUVNgmN35MhiMUR4HuSXCpRLD99IcJWTSMkXJk7nlgj3Tq5Mm0J6vBE8nEIAzBIayXBrZPZ0iBSEJkchLzRGaMjAGSBCIGLkNBIJ7ObWYqyMQaDxfjHEsgwCR6JIBLa/BbUlGb9vIgwBOeHYVYFIClkKeFrgHsuj86jlAJJEXRr8+qeJff8Hmz6fpy3EEgxCTwS8nHGqaa+7ETiIrB0vMWAB2HenFis8LPzPBGj9vdpP3ih6Zj0KqcEcPnHWVLTDK48l7Qz+nSc+fhyDSd791O6455jTR+x7l9BjGY/Xb1FhO4NWoPwXsWAAuGNojFG1rdyyDLwnOUk0TnLEsNuXtKvKY6ApjJd/p86aA444ABiR2QBYcMGo9xHgAAGeICt36e3/H5P+vCAAAAAb+jxOGcbhAAADkY3/CXiFu3QB8kAPmlI2UOG6PP8vr3W188Shf6fPQBx+29SFBR1FlGX+NSc8vtz+pWlEBoTnZcMbXcRbuf2ZuJqsEpsoyzY7KnpCB0s49xSR+gr5tht5hH0mWDiWY13AAAAACAGex0Q3/37AIRxP1t/////+Mv4JOiiCAAAAAAf9fKmay3IJaN1EcyJ5bdkPFt4hpZRPi3fyHGdsTgcAIz+dkNZSJeQ/ShLtfLCEvVENfCINmZP4zd+qIz5lHkoTiU/hJHicurCNrOW+PO5CKAS6K7XkMXhK4OSIKxIlBkzqOiw2gHmfjPnwmhF0Yolpx5Vi+7zOb8XdoPBe/uLSSBE6obFNmDiy0AffCSRkHk29fBESSVafRZaKH0fvDkrBxa67k9h5kJlJyr2rnHqOFvjFrvHLwq0k+zW+DcUQ4bfXT+vLQHpHBwRv3hcRqDmTD6iBFesvrRyFuS5o4pWaQrZmvti58Rw50x7CPh5eB2j4JWo+sRQNb+a9BFvl9jv+effe8UZBsNzdqU64nkswoABC6M1GAD1+bDWDlKJaN06PBCgBRr2wqe0/fC4DW7BI+NmET55TkeSOL8bkCvRPyz9j9a4oACem/Q9T0z61k4nADo8AZ/Fd/k+L8Hwj1Tx32eMMAABPD+MQAbubwem8d0vk+r5she1yidKBGshI0oFId7BKmKQvswEdri3AsbLGiJa8FezAgdLeWVsvtZpm8hVb+n8wwAlVY4MRa0lLGqnyavLsRE03VpQvMO8WHmsABjbrdp0yndCvIq9Y3xl+dKJEIAAAAAB/18qZrLcggMpHCBJbWsQ7BtSG5whLO8gIa3JkMFRJL35HqHOiPUOmVlvSXFdKSo6XO2cIXplF1SNTJE40HBSkaON4Q1FrtKqTcqfSfpff9JkJYiYQ9elWg75NaSxtrVP67jX9zWpyMS4Sq427qHZVMylMJlvfVf/GZR78INJg4IOoUnkNZOBHx63Rfe1njqCFaQfoeLPRHdN+dlz4C+esZfDzp531pZE0gEwEwNoIMfk2Gokip31xVSGnQyvPl8yTEi17qlWkJy+rYr2DmXQiqPmMBG/Ac2aGv8BUEYih0JcH1PSWG5XJrhiLNLttVen88AVll11+/3bv2cMfR3Fet57q0YDYXF2IAAyvOPZFp8/D84rAAAAAD9ygADp9nfzfR/w8n7HkSAAAABfB+ZIAAAAAC93Vdsr2sgNafPMrZkjFjrzbhNCPllODUN73OuQQ0Y7rOLZpEhATWNgFWpZj+YyzkoZ7BlzHzhqVLqmNoyqPAVVLTk/u1RNI5GgtVKp3GIp92W9ZYY2QnA7Oulok4CEcT2t//////jL3RJOiiCAAAAAAf+1yirmbBDsW4J9zqE5/KCPAnk9vlCNLshHwLoyfWtrW/GCWw46Q8A4AjueTVjyAjsDkFyyOOzJKRfIZLiJFSceQSELUVDYyGa0UE60EnETM9CuDEiCJ4HHULGyDFIyDyofv8jJV9wrGHeP1UiAZDEpIaDFWsC6QEwNqVXJlvQPeWKSUgEVYchHt90eKTKCuRyhAmWDgBvkPyBOeokmJLovtXcP3qNLFD+0zHZgv+BEgSAy+COzadLfX5/ITAMjLX+4JFDmbsOnrNDryZwkBGmYT8jHSuJ+UdmZl25omuhZd+Y1RkndskXJveK4vFNNy+DoCQLZOhN8/CxCTGUWRzLRgI1G45xVOACl5jCNZEDKMq7/0PQeTQ9QkYkc3yVUSRkJAWg/dmhvXn/Ym0aBZy4g9nwuK6tA3UUSN/aw0E3Y4g9z+Ncrq9MK8+/lvHfSwAA3/B/RPEdYbu35kDoYBPy/j9b8o67ZO73P0vS8f5fmAADfrflOYAFcbjaOkBsUtl8kNIaB1DNOqk9f3/Izc5T3xvYKBG4Z0fsK5L1w8q50OY1iMRiq3IzaHuzSU/76W6DRrqCAZKjj7MCMBNB81oXvIOUC6dnOzIYdN1ozh69ejig5IL3wXGX2TCNEMIQgAAAAAH/tcoq5mwTjNJ4CkTPnSHfd2SxFMmfLEQuJ4DoZLL8hIH7oT9o9BIE0hCbxshx3XkqkiTclYsSX4+THkxiotpCTB3KSHiCJ7OVhk4kH6lQofEJnDx/j8foW8reP+I2FP7SRwEBjIIwpCvBugfQVoGwZ5ItLPW4txVwPJlLrGNkOsbRWRlLrBXyF0kwQ5F0Gig/ZKSvXVGfMesyav3SoxY8LgoplB0L3F33qvKxJRBnSATsqouLH8C7t/PdY9HeT3QHmjg32hq1d4E72ObOZdlaZnYma1RuwSJR4pR64/UrIkPL44DXlztdSLRMQIX8PQIBwNe34WBoAYLmh2shYxMjSNEwzjkE0DYTTL5Fdlp/cP0Lh+f/JMQAAV3nx342AA3dL8L3PznduBtAAAAADLuWwAAAGLgH61jEFvhLnQA2xunQqaLrVvW01hyMuItGLiTBsjeE16kgjmmvCr0E4ZTUnYSLuPWI6NF5Ks93VQi8hjvoIDQhG1xdSI6TRkGAMtUrujLtbBajtWPi6+arghHE1n//1///4y/QGTooggAAAAAH/utVVdXyCV3NkOe0ye09w3TwQjxvj5GPqyPZSkOHzCIs0T4x28j6AlEewbol0PiUoMrnEEcjKuvJEKkgjMqkgIJYcZKq0mcFr0sDH+4ImddxrfYSWyXBEJcv8VhF0IIAVaSNSETp4pJAlV3dIcXTF6b62JphubIZLUFb57OGTr4InnMNdJPqPK2Dk51wY/Fr+lZ5OcMhgiclxTblzWxMJFhX/38TknoIOQR9w+J2HmnPZMIsfRMiUzNfmNu+RNziub8gDYtdk2gdHFcYM6d2N7+DkkJ4lawJ4nMbxpI/Ly3AcvcYcKDL44yhkn0z4uxQd0fbng6UUkCERvtbTQ5abp+b31i7917ZgOao/PaDIRRVkSFeEM2NStxKJRkWkTZtssamnccjDODwXtdyscLnO36WkoMRgG/1Tv8/tWQK+W+sfHNCYAHq+d+k/Gfe+k2AORwZB1fqnc/Be6dbByfxPlPx36jAAAv5v5PtAAVjIH/A42ixooe9hs77lEEO1w26X9P++V0Jsb28mrns9TDtG7d7sI5Pp0M5D3JXIaF4VfMifHKARL1s1O6l6vualyWsbkxGchZ7kd73cNUh2WmBxvVLatFTWOdBnVpSmRp2qyMvskEihRRBAAAAAAP/daqq6vkZXERNeIrq1PwgjsdWT0PHCXRZ9o8XzppSevwhLa5kli9GSq6Yj1p5HboJzcuQg5Em65gGVtCYQy+ZIcTmkEPJvlXmTDAkw+ip9CSJYnwpMZyC0dyUUYlKPjwekrSVYwLOcSkxSehzX3f7RgJLRhy7LmWFU4FiUgz9QJhfQyPvNDAIlFrkhLbMFqqIIg5Xj1maUB+GxTpOzAkhodPtf//8R966EubuR38eyuquq5EkMhiU9MdkTiwnIqQandcdyfEt+nM961tlPwXpeIkGOy1rXQzHIeK8m2F6rJP5e2Mpc+jAz/7877jyaSsif5NeTw2AezkjRPb34d/r3LTUTfWYy3fxvVpQ9Lq5YFUo/SuGG77t3buPyv8b58gAC+R1U+tSABX59756t9k43r+0AAAAAAAB6fEByXC/EkSM5eiUGHXGQAGgYMdoR6YpElb2nC+ac6q6zzQrLFvI3aBvw+hRXW8PaDtv4bN4eeuXXCohBWgOzirT6WVerb/V7oiZ9kKg9OvF6k0NgN93hIliatIXwhHE83v/vv//4y/glCJIIAAAAABr/yLwy8BLypmye64WR3W2J9RzRPg2iI4awQ6hbJcF4cS3sknz/0gTtaIhWzhNnJiGjskGSCTNjYmIJRLuVF4OgmniZCnhuEDj238HMoiSIXOJEkMjhW4IMkghKICgjy08ndnNv0CWR5e/MJ0cERyzMelJiFz2TNWJID9VcJAJ5GI4KfJme+i9w6y6byDHz1+erEJEMcnAwlSz7dPnHaNOdOVmskpGhfDiBpPXf0Xo/pC0lrUEmBJBc2p/bYwLcLGG3I92Lo3NktCnQPTllO+IND4+48M7Bl9+b/O7LkuUgb1pWILHsPrvS0U6PfQ0KW+6MgBIJHLSvBLvHHwAAGBnzBBsQIY1vu248X7G9cKPD3G+CpxmQfN3M/Os3viNyo4iubM+UzSbnyMhvRcBgxZq8+WAGwfEWx/hbX7TloAyYwvn+b7v3b+M6PvPofrHSAL1vwGDLzn2HuIMvVMMvzb4TTDf896f3n9PxDhe++444gAB5n69xAAKx80CtDjgACgSohOvRSe/3XS4mBYWZGQwXZ4THtckIDd7XxW7eZ8cVmgZAE9S/CG1PqRYTaC2roxz1pHtA1nLpCUD+ASiMRbsSemaZSV7kOHpCAsyFLfzxl9lSJIIAAAAABr/yLwy8HfZNVHKvgojouK1sMmTynOuYJzOtz9uyffuakvD+qJZfLEemaMkRFaIJyxk+FQSO205GVMJNQSd30mfhZGUIgzJTIHAgZDLJoyIJZKBEseHKWzoIvYpAACKF2bB8X6RsEiCASjAtKvd7fsc3zu4hSGRYKhBe59DfeyY1S9Hz9+xSZFCrpZB7QFbws9E6Su+vyuX/Pct5MVKxvm/tfDesty/M80sPfuTTT5FsQ5MhurNG0bsqhRaAU9aXy7yZHu+W5I95+n6w2V0mTITCpaDs8oen9d9moRItSGm+Y32WG6da+cSmLHUqA5H9LfIBz9HyKrbjd7KGQV9q8IjTCOuXQULBauABn3TnFWv3OBl/uv9b71+C/o+YCspvbpyVwP3n5R434XaA7PaG70rl9H3eu48MAAAAAB2fC6QAAAAAANTqtUAAAEawIETow4tDfXUJgUNOeoNEuAYfnuf+kDF9hqEOUi8SFqc0DDRyDDeznSpQmcdk7RQfbaYrmLjzn9jJwnmZKIcHxoDHXchwa9pEXY9bY7XP68CEcS2m/fz//7jL9JIDJEOwSEAAAAAAX/5zeqVNgQ6L4BIdsyROLeJaLgxHg0ohqNoRm4ol0jUEs9ysjprJPT4IlxiWRy2boA8yDn7j5PFcGwUxCcSZwEaHGyGyzRCsPIV4goREMAjAHwXJyqJbLckmy8TbJoJ+TY5GkLH0iuB2Mz1vtInVwRHO46gH53DbxJUPZr/qJMB/9OVohKhLI8FsS6T659H+5tNe3P0c1Z0m1PAIOia74xZ3Fo6n9LOT6lj+BYku0C5v65gmYMIn+ESkTqmN/48KjyrFZjq1zvv9j4XBAtGcCk+RejVuM/oM7nwJGw2JPw2lpygN/aZcqjNVIR+MviWaiAzWcXn/AXZ+fEHbEj7uWT1bgvNXW9HaX5upjtdjx3nUZ84h13oSM4/x3X+K7rY6QbaISjnbxZ1Re+y8L7RVNQHRv97+Z+awGOOpyfEf0nd9gKx0y+f6x+ncr0fg9D7l8x6yAHR/luirL5300tSM9b7Ldhtf6QGc6HL9ay3PP14gMcez83tAAB6Z734CAAYdVAHecOQABMh71INMD4pKbXRkId0crEZaxtrJ6BHqDG2QTI9n86lyVkCi8/FEXrFd8KQXRy5V4hrtBTFQFZrtYYUFI8xdDJn0LTO3xtUKIogZLTkxvTzkXsfjL86UQQgAAAAAC//Ob1SqoCHN/BxDmu9I4XwOTvXCEDgJMfgO1LVbYQj0rbkOQdyJ5nnMo+RSPgGXj/NkkTCUvJE9hdIbYmPduRn1iWK5pY3GCYhY/mEMi2zhYND+QpQjaTd6qKk2tQuoZIrCcjAk0JtI29bVNQBCNDQZPwdCizTW4sgxOtCMAmY7Xhy+LByVlFJUTN0gAD+7MmeNsPpogmoRxEshCTTs3fYfz/gNQJqEPSM/DsYvdEbJJ4nOL6UtMJGauXVT+lH4dMyMxtMAxTXMHfHNqjyHZmOp5znInO2jep47yQ8t/+dbxJhGO0e6MpQYRQbn0GI44sUd5UloanLLm/XdXQfX2Dg5VS6JsLyVojPlPfkxpiwcLhynefX4JnHudbpE+Br1bFyfYMd6w0u/QAGv8fhfecAMfQ/zfjf49LIB6XWBv/Oj7ej+tw5AAAAABv+18P2oAAAAAAHL8WQAAAIMEw3T4MIvcqTL7VLnxwIGKvHymvj0aTjn9Qq0w37kdwJcVv/bNUQr7H0x/zSs+AQqnlxBvOqg4+Ad+Zx6CPj2oSvh++JhjS/N3InM80x2LvmNab6dlb44hHE5kz/////4y+UKSQFyIkggAAAAALf+dQVK2CPgHs5HiXTieS54T0tkn1IBDj/ByZFEdL2wnhuoEuh44hwmOTwu5IReek9PcJWcfg3ASVu+QOT0MmcZNMUjVuYPNJ0cTdsvAH+S4EwkhhJGO/rEEhJVZ9ZTSZCWlosrRfm6nteNTuwknOk8XGlEFYB7G9tJpHwgMfJJhAQYAhU2ZEuG4D98lcOQ1kwxJUr921sLWGAxCMReO93rXaG2zMDBF1KrrgiCPKiv08rkjla8Xa7QGShxCTx/pvpXGPjmOyqV7u0vL4/vnM79XCbdZdjfm52Nd6qmR9d5Nf7d1BNnXUCGvZQ3U9QB0C5n2T3tLiNnUUbt3UOhjILxu85HjH/IvNjH6/eev424X9TG1UtEFLOb0eLq3OfA1Q7lqJ+ZcRZq937ekGmPIg7f7V9B4cAmf0vu3oICuo/rfQyY4xofG/r3Bz/u/Mga/Hm85L5/4x0/d9PPy2bLLBdyM1bl3ep7Nr+y+/zRl/jfw9vIAM93Iivxu0xgAHxdGAV1HIAAHqbsitRh0AfzbjNJHbYd3dMPqgbXvUjZjH/NUQ3FFEHniLhVS7AZ+6/xodDjE2ZkBq0jllWEvXpR4+NkaGk146tcVoDVdwKdmsP3RhMsCvBdkZfpGJFEiBEAAAAAAt/51BUrY67J2qVo9kl+SQr8QIRulEeLyCA+FkCaslpfHt0+ASefxJDu2TIchyOQgk7Sch5wndxpGpNzqsnZ1JDucOhcKSbwUiwBGJCsdH4m1wEXmrIhBNIlXZLzJQlVjd+QIOgEQt4hkygRfw8ldPAPrs+hIEbQTSEgBNBs0aGItjEnjoolqD7RmYWQImpbPV3uTip+zEIMgmxHQ/1Ddsc/xeG7oyGTpLVHGWxOiOkMbyx1AQiyvKuNu1ub+M6U3StcXNcVulGX81q+lk7H7plvLdmDu4f2tRNUdgbRsvXV9Wz7f19F4Sq7m4Be/36Tk0MNl1/auRoizFKGLADUKVZSnTvuupFZBcDbAbccaUy+hhhhjEg2tJt2+uTJhgAGPynw322wZ+H/au5bQBiC8b1fdfXNPLoO6aAA25gD+H8AAAAe7pgAAACfuAEv5MOdhuKgTf3p19DOUsEvS1Fl+G6xXbV1B7teJV9NjGr0ZskPV+RdNnwyobMO+TDN8ipdTfSf3Yy6Q46NV16eAQ34tDictUJUpRDghHEqp7+///+4y+0aSIkggAAAAAJP/dVJVXyCfCtWQ41qCOw6CS30Ihv+NEb1Eh1UZDf6AnzaYT6B38hw3KEeX+ASUHwiT7FmsqWa2xpPA8mqcRJealw5M+zoHQWIojCx+dz5NYSOy0R3Wgnd0GpM6qJ0X4OHjseh4hCgjlAhXdqLpGeSRTEoBeZp/EQGfIeEzT9O1NOh8ga0nNm28T2epQ/pycSGTvyLXZ7QQc0gJFZQiRR1qG+rsHsK7xka4pUMSGyuEdQ7zrEbli10pIKZnSiRhFJZdNiooc2y/3fInokoAo3Nv2bn6MoI4HNeVPv6MiBRcKvIJuvXJFJzhbuyn2TeWk4/7TvX9HJNyuq8rfF8jqD3uzVZ2HT16aNqu2L1XIojpvw9+VfpbjWgA6NOFg7HQuFES61uRMR7Pa+D7h2uPcghmvv3CePDOjdobqzxAT4ke54Klgz0WauJA0y7sXFFE6yGI9M8td7KgCdEjJrtYjDheIOiiOSTnJNoyq3cUSERUGCEAcpsxqJAYLmxcr839Z66QAdB8m8DFfM+DACgAHC6WAAAPp/mv2pWXQYvlv0v143O5DyvGdf8L5FRFc30Cth0Paq6gQGKs+/qYogTTTbFrGvSM6vsZ4rLoCvTP/Ka1XM0DmwbX6Lq6NPtYvrceB1o6TLYZZzbRcvE0ZezDYZMJEOwSEAAAAAAk/91UlazkE+K7khP0BEPKSfRbBHDUyfe+kk+s8OJ2cMQp8SI8L8BEumwCVXhZAWAI7rSkiuJRNGSyMQhU1WV8h3gQp8WJaKlgICJMwTcO3Z8sm4FQBJbJgZiSzygX12t0kKdLBTkUiIFC75OCTg6eso/itnn9QJORQEPJsDRfM+aiI4JCil38GyEC9iQCEqUKZCUCCXjEAVLvhfv6V8u5sziRM+ZZPixEgKyH6zZO3HF9i77qI9unIogSwkmVX4D4/xj1GrxID97+9ekqWtjwwyCdAalIrPi/Yv955AGJqVgiGo/1XOYyY8YjtQu18BTLxOUkz7RfdQDH1lx+/5fBNRhjUp0wYBn+D9K+E4Xbf/w+RzAZa2QL6H+w/ZsAAAV9x+r/Zfkml1XvOYAK+geFzAAF9HptedSAAA+YAAKd9W93idh/k1Klmm9ZYED9thO6k6V6gzYYaIZUxvDdw3y7yytpeDQWtEhM4WBXv82WubNMWL00mNBiDvMgrzo7KGV/LEGxjZKM4wCzjSOxbZxK2a83IRxP7//////+Mv5HIiSCAAAAACUf/fKXlS+wT9U8NJ+Ajk7vWyXmHIk+GaUnUzBHL4chqeyENnOITcCT7Lzgjv4RLlfkrH/RiV69WMIlnp9ihIQ49ayiJ9nLFogMZJWXu4NUEbZyYZ2VFkb80kxBIyqmt+fZXhTLibQZ9jqWXipEIiA+DEZmGoMEhvP/Am5pIwqBPUayRZuQJ5PHwLOZg87AFE6oyKjkDLu6BkNd1ScBcQJGy4TgLzujyjjof56AUThEx4nAiYK0gyDfHtJFqrGHRaScktTiIClkoMvD+OmJDhe01ybpitE/cpfSTGKfC1KT0ogsODKs8kqkJLP2Lx/+m9Znc/Gk6moc+fsmgnrXu6eqfL92ZZyeT3l0hyuOVwt2XgkQGosz6jqsx1b2fkAH1WZRNk0Zve8hshov6GcKJJ+JvMZyZYnlGOZwbt3ZCwUbXtl4t8S/8wNBxBrVTHbubh08f45zK3DC93gD3HIvLMxGGqOhDAM79x0IACMuHUzy9328apXlgBT9vLt6QSjEp0oDJIp1WWs1nBiwEviAisOqzpgxpQAPSV8DG/k7uUACuVnyceP+Pw8wGfX6AANX2FAAHd98xoMK8flmgEjEE4TyHKndKW6pLltR20mBSrvIG4f6HzkKUF5AZ/VVto2ujd7iJHPlTQ1e+4NHWaxQoTteplxsIv7TO4j9kkKERmRAt+NtKgx4Rl7cNikpkRJBAAAAABKP/vlLypfYysAnkNSR4LhyfGd2T6PvyL34+8BkH8MIcC6EQheliflaGR5lgiXP+5ErGPIGjEomBJR0E7oSEENYRiUnPkUAx6YhXokguu4WPo1ng+PJJxd2mx+ciWFUZKIIRFaxS0R5OBLQCBIRHfbEk3Efs09epAKCdkdEC+m/qqnBaeFIYVe/lbC5jruCTqXrMgEBCJAjk4FbgZAyOo4V2nJ4YvWhu5d2EAn6YmUP/CThdXXcGoiEpDCchloJlB3JXDtiWIKMlPN3jnj+2N1CUAI+4s/1iGfRfPqRZQ46cZ2QCDHhl45Ztt57dHKvZ/XX6/biPw9MAFlVy3w+nfr08LAgAAAAACGbYr4T9rN17+LxuOAAABlyelgAADjel/Wfaon5NIAN3jvNSAXnmSvxfqmGHqPwtgABu3/oAARkNrAPtI8Z3jH2QiEhjel5wEwS0CYPnlAeYjYgGMPTEea9/wkeEPN8693LG3o9G7mjq3NLKB4fVDbG83Okv4Fo/0UsvmagIt7CYbXHnQlCqJkIhYg3IRxNrfv////+Mv4pMiSCAAAAAAP/NMklNgjy3vdRbIh1HRk/WTCHXohDh2nIq5HdmxJQNGS8UfPgj2ztZLmGpJ9d8SksbGIt1N3hIxtUS1ekIyT3aGT8GT4JnOJXTf+nk3pltH7UksRO0QmCRLprsZWcGfyWdUypBsUJMIWxlR5ObmSRnkxCIGl/paIMS3GFJBLdgybRElhJzb5PgcTH6rfV3pLC5cLUEr94TIDIYZ+whM8neNCJzsJy2gLIcL/+wNJMYe6MEDUatvf6iII2VjViypKGPoeDg+tUGLRedWWRiMOoMP2zs/8RdguuOwYLnOBOrpin9YcsY58k/hEgq/08uZk+L8BqUGanbsF+ceSFzPxG3Wcq1suZAXjKwN4wfSNk33/Juq25gSN7EsWdfMW8/BoKxOpNcU8q18dfDPUe6rforNRWYBzVJVk7fcOsHxTxVxUY76QYWlpWRRQHRo4i16qFFA1KcSBHCMUDKMY3Pr5q5D3Y1LywAZ55409sF/M/uEFdF5rSx0Q1vHfRvi/ldEBj7v8pzkAAAav03w0gL1cRnIFd918AAD/U8szrA9VCDiTOl1K83ncIA3z++x+PFZVDQAZSUU5Iciw9Omtv36KY5yCMwzVppU98L0PlFYl6srldMY1TOtSF9fKfYyzSETKyI6LySrqQO8PlGX4yQFSIkggAAAAAD/zTJJTYIpKQysInjejkeU9YIC6gQ4XzOg+ck8lMIaHoJDIdxI7zycTye7J8sTUnfyUMmBQLu1ZGDwshxCjJw7QQQ4vksgJJErEIBflSZEWK+ogkxVaxQRG0hWJ/S/RJ2i/fuQ1IncedmUPiiMl0sCIDmEQBIQtQQws/Hqtm4+R9YIMLgOhrcv8fMljHIPQRQCsx/8P/lZgJJnkgGsmtwST1jlisD46avE+kv6HOTj5nzsEiYhAcGuoWVTk0kUPKuBSDNm8ey6FHZoac8Ybk8Qw69wXtTv+oh/U/vy7NcwG8h4+vTyE6PrL4x0FPeZ/vNdJ6u1flnT/m+eZiGAEbGnHRjlmscHW+RrUNzn4u6veLgAAAAMQHBRPavuzcp52ZKXgACUNxyP/PxgM//e/Rfgc0ADjZF8ermOXRmhT9pLsfRAAAAAFZDu9UAAAAbm6UjfIWfMOjdJWvAKHmvKkgf3BHm4zniMvX+DW2cGkpYBNjWQ5Dwt8cFmK02KUclMb8ZCsbcrAKYIwq3GwfPM6d/OX/u0cxulSvRwMNPV0MD4vaav4hHE9of/////4y/iUNhUiIIQAAAAAvJR/5zJKl7wEOg8pI8C58RxvGiXgzeE874NJvvkHakmDrJHCcmJdY8vkOV+liRud521VZWiGTATfgyE7kJENMgFRAZCLMLgJaKFgoCNVNjx61PDyKxELutuoZOPJIQn1wMmARGNPJ3hkki9tooV8VpTIV8JYkj+lQYJOATNB27wDzyf051uks/jCBS48JWB88ETPIzF6Iu8RNFAjPp2qmXy1yWXCewSeDKoSEpFBIrUMzyfuUw90W4Hj63jaOvgm2DnYJC3C4+pXTNEA7sugRE4/osR/B0KYrtLrXN3i8R5SYankda1kntX8J8o/ut6T2pMHe/6nEuyaZ1Cov387iMoRLpbSKXknD6vzRAMwzd4X8rmjiaV7tqK0zuXlTODiEBr5umGdAR2jatm6QVChcyCKWWHLGc9RPXGaYadSi7mvUAAAAQ405LifFac0AAD2f0OZZqWAzUeZe4DqOUc0CABgi7MnXJSH+HbiTr+PSBRSnxnVpQAAAgSHIw7ZPQAAAI+qoAXw6a3v1QBmPqkABaKKBCe1vXPhdHtfo/E122msilz6jsJFEfJVRIqqBoqIuCih1N9xlqnaNEWJAs+xAsyFpvIp1nWP2IKh4mSIonKNQh7vak6GBw0j50IY4mkI5ZcIy/SlEEIAAAAAXko/85klS94Nv2NKytqyXX8oSv54k/xKQ7BwolDQQmbonvOkkOEczIYvipGvx8j1rjkzyCI4hPa7QnsORkd9ZyCGTeAEvLGgJVSkNBi5njVFJsdGmCLppJ+VypDyFAn1X5CxRkLWLqcm4bQb/ltGmSYm7EWYyG0bgsMmMZFIc4ZDVgAbOMTmSZUHsysjWkYkOoQSXQ0gW4SxMfYg+ub8s8svU+wJj/beh8sdvdOdybT4aRCaJ1EIlHg28u6FYEPxmBfAzdedrCoElK8P1Ii6v8d81dTmtuiQVkedgZq+pymXNaNyvED/uca56/MbuoVyFVukEtNusxMyqzB6BoZreECRggnLj+G5QTGFRzTG3t/XFqodywUUcsAAAMparDkltzg8aP3LziLAAA8J8btzv0/Pw/sH7xkAALx/rPjH3f87sAAZ8ecMAMuNpX0PFgvPV6XDoumkAAAAAoavmeEBWiAANrJ2aY0sbvovf+XDB3IDHXplUsi6vPp3BA9WZRHenAgxgTlD6jhct0Ii1DHW4nSHjwJRO9nRtJRvpHtc2uJlkKIK3A4FEXe8pPiryAlsWKAOAIRxNca/9//++Mv0pRJBAAAAAB+v5p/5kZDAR9Gd2IeDOyEO08qJ+8FEeJOJ3O7E7saXeiES54htNaT7dzklvcWTodSJ8qhXRfouQQ62sjh+eEsO8nBrkXYIlmYRKqYnlJxCS0hIWRPNJoVUzcq7D7JLs8jDAQgjtFM7YIgMczIs8P8WoAEA5Ene0lnutaFoBFbiMef9IycEmMs7hI18pytRK8qPyCrxMm5hFJZbj2amUSkMSMkyQTIif0Y8SRYnO5iaRkAO91yED+8oWoPWninCl1jbgZQGRPSIDXRL/m5DzF9ruk+BB+L8Q6B8lrUGnO7p6tBauzL25xiSIAkc0vn5+tioATznHpnyDeeX+Ketfqum/IOL88T4OIVkr2b8/kt/+DfkdgwqHUro1SkJ5ceW70fn5TrWOeS9DPhc7cMzlVSZfEdAzW4SkSOA0tT3VepcUjGYTpQZ8vV0pCvPOv9R4WPq3n3xihyfPNmzWkZfI/8T+BN+Z4OPe/lXfany7yWIGfbf2fXzlWGFcr85/sv5PYOV+X+0fjf7PzeukAAAvi4gF9D1PI7fosAGefQ5gAPX8hzQ10Xe1GLu3aee90mP7DGKgibR7hlivWDVzOznNM37fFDb14DjA7Zr1UCysRnkQLYD0Et1g1UhOn6uLdtbn9a/CQOUEk03inUaWkSCw70wjL+Aw2GRCJRIVgoMggAAAAA/X80/8yL2YM6IqDZEZWxu/VEsnxy3vJRG7oie88bE+L+OSfB+F1PxMh4F5cQbCJ7WT2QQtmIanYEOQ5sngs+TBCJT8gRrxCI5+D1pdiXS/5+2LuETy+AyZHwQJOGTyMkVJMtQlPTxcSFhqIdlUdm3JTpkTszoCzA4+aQjNoBcuFx6OriQqJCHQlwnutQDyYQgdlmj/IQ2fMF/owGF9Id5zEMmr9AztL866So6oRff9wclvu6x82tVnHJFoYd477FUJeSIY7fN7XB3T8HHrtdsc8t7ixx+h2Tk5v7yY+XNT/rPLdF7B+o56l5qlMF7RqIZenDrpJkMVEC6WICDKhbqDVq7RW3fvWW3frhe8HMxxn6K6fyO6ANCmNFvs+OWAAChcaHP8a4vR/Qa0AAAAIUAGOaHLwerk0Gy/UVnxQAG7y/HYuT14AAAAAAG/uvqfrewAAXofFuZhEAAA9Py9e1REAzkAAcZuCBNkXskL4tXYzfrOpXa9M75udUAipJ+q0HtINKhvnf8PUebrkXNRDqF2SQLhdqMLorYWAF3XnllkrdLtsfWA4e8gkGWZJUUCC8NbDIoeAhd4ISxMTX7f7TrWMv5FIiSCAAAAAB/P8P/bvjOKrWAT5VgiK+5kOXe9yXxB5qRxfMiHF+wE/I/WCXONoT792Unv+oES+xiR9UQ30clzLiRMfEp1hkcLbIcz4GT4zCJWYXT5LhdbJr7Ry5NgyZ0EkUiDmEYCiDp93TCTlzMUmMpOOMmgEqvwMMzULfITTFtHDksrryCJfCKyo+oIREkz3/VhNJMhIyZwAnZXWFP+PykTHCruWSn17sZWK5ctEVQOJkigJhZvCgEzIHJiyJ249JaaCS0/q8DDnRODKvT5StgkpCu5CJ2E4EG5rEH72tyfTdq8fOTI1BhjXMARK7hTqCMbqCQCDH5yYgzMTWrez9F5gmyfQaOsYvMPkOXNGZy7y5rtEGRKEFXYrGZqeEwly03BnAuUdeGx3THF9O1e+qP/P9gZh6+2BJKvIsdOx6ysrVDQkWKcyj8/HCjmZ8lAAJILha2nTp07G1v+Ww2Ccmr3nqGlAA5cJxrrKAAA1Tv3Fr6VrkxQ1RxVcajdVOJBBAAdTkqJdzlljo4c+DiHQxzdyuOOOAM+QY6fXGT18encgAb3uVxrWit72O/cd/IC+r+/nmgACGsEZ/Z3g5BqAAoh4ePuADHKPf/f1yx4A+QGvJD6er0WoDKGPV4fbzS4xcoxpx7CD4AI9OPR5fnghyKv1/E1d4hzDmPt8MHu5QOdxzBbPtQbd3X17SAh0hLrIy/glDCQzBIIAAAAAPj9f+H/tMtVmAhidSQxeSI4TkRLgvFCGGcTve9SfBORE9DgSHJuXEsx6sI6lRDinlUkjQkbeNIUeDUHCIZKWRzbiEaz/Rx8ghoJhF4yNPEEykJqOSg2CEsd1IJ25tAAzoXha/9thybKzu70zAhfRWiAkzckcfUlalK0noq6EkbWStcd0goodvBJixEoFro34rRxA6CMHB1nAoBHnJKeGxa5GrBtJFiG0ZwRnneDkNPlv60kpVqD+qTIT/wjzJFEGJGMTbGmdZMi/YdVklj/4+xwPeMmi6QoNsaLD50XcN8x59KncMyimVDF/FiHXuke6NpOpt6PprilOOOxch4wuktBFtQedirPTldgcqlzDe7jpeeojohZz11D4biP3ChQUZIOx+folEnFlxeYIIIkYNXb1zLN7c8f34/Dgggghtw8SOAAABkkXPrHvdZgYAArDU+U/jPe+M5oAwhnr9n47695n3rQZ+a8BoAC8+r+Pc3yGh3TpOJhEAAwYRGpFRxKw1OJ0DW0tWBHT60AAAEstjG+U889wC65vrhWJXEJqBhpOAAFh+r6ZjoEZan1hkFAkAB6g/o/3dNS2DUABdHj26gB1uxdbX7r71NpNhaa/6Y+C4YQAPG8pntmZKC9jp7ITqDKgqGa45kz7Q1hwCChTtlpkJowmJwDf4v8X1ssvx+a7/9g6+/H7eavrV1pFfj/+LTrzckJWv6Vd15Drif5FBDX7TvDvlU9VdNGbb+NTZje57EGLmtga1Hjbd+NON6brPA498uLnjhe8ZWD6ZfOpdAbDN26iDIbwkUaXCClydwcZQwoD/P/pXyvUx1v/8JO45sG+gHSQGyOkgCXQumkd/kCGj4kS3O2J18WTwuBI8O0hGdHJYPjhO+QhwHEVNoScvYEtjiScshDmGvIv4ORZXJw8jbuyokRBkkiUNZaAlHRk2hk3Fks5NJ7LAEt3kieX2JHCyCCJ5HD6QhWyJCvwolpNUT32AIcrxJDLlJX7ZKxGIkiE8xvyWSiEUHJVLxCBsid28QaGtscS4tPIcBq1OegZFrAJor9BEuC6AjCmWewhSmEx7WsZdpZPO+EJ11E4dskEZGFSl0ch2bFJVDWlKyrXJw4JAKSPAY5JmMJ0J+A4AlIxNZz7Qg7eIjMTgMmFiwaJYpSRiWJE+KrABGzGJQYBOQ4hhIBJcCf3pdrcw/6LVEy+l2kMgl3cu0/6lExyUSdUIiNMRKXIJjcKMKMKMKZ3ftL751P11+I7T2URkBJOj53dj2MSdGye67YpJ0U0BQAsA+I6b1t7B3/l7sDv+61VLAJLfb66JeSW6t1zK5CgSoBVgCiUJRCi8mugSekhQeTXQJNYQoNJbHeEz7IjuxEtnuc77SxduS2m3n/bEZvBiPGqeT8zJmOnSESxwiRcYRxGZJ0rxDMbQlyTNkXaklYzFmYUnKwJPLjI9EnE8pliWD3ti5onkqJLDYghpLpPOZYlEoEM5aJx9oSn2iGcwpPF5UlXw5C/dJx8sSsyiGSsE5ONJVmEMdbJw8MStIIZHBkz48lhBEMZhcr4qisMQxGG47hqDvELd/BbOP75CvfIjqk8AYhTwBGLiCefkkMLnyM3BE8/RIX8+Rq3CefsETQsEbK6iKhkguzuOiXkjm/+8mkil7XIjDJxZbKRQaok0WUigdvGoMJEgJ+FLYCIg10HhQkQhJbPPEYmxIaBxLX6MifXENKAlrNPWupjE7Hfaknf4v8B+AnG9Trx99cen6vv8vr95ftXf/9P78feolSlgT57UJV9sS4hjiPXuCk9tEx/0miKeQgEoAbvMTQOUQEYaqkq+xZPlY8LRR6yNlZVoq5NtIRMhrny7nHoHHoMcy8SRv4JMYZQZ0R8ngafytoirV/KsZaV0XXvBZ3HvbMUO6X3tBPxKv0DqdYzmsLW1JrpfUrocDlUm+3XDiTpcF/aW7wUWPWszz34XCrLbI3m/JNWZRHCSYhux1voVVvEa3yHGZfL5fL5AAfT6fTX8vl8vkAB9NdA4/KYAJGuhYJ/IT76kvQf0DIenfFpDlfIyfyD7OQ/Gp5EJQEEfj78Gyfwq/MUQ/HB4VIeUvPZHjHiMm3ywQ9qUiWSGQ8X+cCfwrmkdjlCHqDmxPb+OyHKL5P4lefCX5bvBxCT4kJflx6wR+sXzZI/h3qk/it2ohtvwZk/q743I/ND7SEPw+/cMn96fh2T9qeiiftH2vRfqYl9q+VEvkz4bI+//ShPw52on8PfiiT+Evs8n7X+BxP3n5+J+pvVBP1z5JJ+V/PBPzt41J9k8bE/AHMSfaO2E+69AJ9N7OT5ZyEnyLmRPjGzJ4/LE61MnWwdnxicOt7GTUHqAj1D1gR+AntMj+Jv4SkdVmCPpD18R8c8OJa310S+AHSyPtb6ikfuz9jCPy55wT7TiCPub5Dkfip7tI+pPDZLDeCCfF/BhH217eI+jvABHsHeCPb+ykfGfsAj7g9zEfX3qYj6s9YEfUXokj5v8tkfK3l8j6R8+kfNXnAj5+86EfKPjEj4q8akfI3lUj4y8XEfFPiwj4z8bkfGvjAj4p8QEfDXh0j4h8PkfDXhoj4c8NEfC3hYj4X8KkfCXhIj4T8IkfB3g4j5f8ukfLPlkj5a8sEfKvlUj5W8qEfKXlIj5T8okfJ/k8j5Q8nkfJvk4j5O8mkfJnkwj5M8lkfJfksj5L8lEfJXkvgIUDaRgjBwA==";
						v.volume = 0;
						v.play();
						return !v.paused;
						
					}
					
					/* Enable on desktop devices */
					else {
						return true;
					}
				}
				else {
					
					/* Auto-detect support */
					var v = document.createElement("video");
					v.muted = true;
					v.setAttribute('playsinline','playsinline');
					v.play();
					return !v.paused;
					
				}

			}

			function isVideoReady(video) {
				return jQuery.inArray(video.get(0).readyState, [3, 4]) > -1;
			}

			function loadImage(image) {

				if (image.length < 1) {
					return;
				}

				/** var src = jQuery(image).attr("data-src");
				jQuery(image).attr("src", src); */

			}

			__construct();

		}
		
		
		/* Initialize slideshow */
		
		var slider = jQuery("#<?php echo esc_attr( $slider_html_id ); ?>");
		
		new AIOSCycloneSliderVideoSlideshow( slider, {
			fx: "<?php echo esc_attr( $slider_settings['fx'] ); ?>",
			speed: <?php echo esc_attr( $slider_settings['speed'] ); ?>,
			timeout: <?php echo esc_attr( $slider_settings['timeout'] ); ?>,
			audio: false,
			audioButton: false
		});
		
	});
</script>
