## Cyclone Slider 2 Video

This theme allows sequential playback of `video` elements in the slideshow. Video duration is used as the timeout.

### Usage

**Set up**

* Download package.
* Extract to `wp-content/themes/<yourtheme>/cycloneslider`
* Rename folder to `video`. Ensure that `.git` is removed.

**Convert videos**
* Use [Any Video Converter](http://www.any-video-converter.com/products/for_video_free/).
* Drag and drop the video to the application.
* Select `HTML5 MP4 Movie (*.mp4)` as the output format.
* Click `Convert`
* Upload the video to the media library.

**Create poster images**
* Mobile devices will not play the videos so make sure that you create poster images.
* Create JPEG stills using a [video-to-image converter](http://image.online-convert.com/convert-to-jpg).
* Select the most interesting image.
* Upload the photo to the media library.

**Add slides**
* On `Dashboard->Cyclone Slider`, `add` a new slideshow.
* Use `Video` as the template.
* Click `Update`
* Set `Width Management` to `Full`.
* Set `Resize Images?` to `No`.
* Click `Add slide`
* Select `Custom HTML` from the dropdown.
* Add the following to the text area. Use the format below or the slideshow will not work correctly.

```html
<video preload="none" data-poster="<url-of-poster>">
	<source src="<url-of-video>" type="video/mp4" />
</video>
```

* Images and video slides may be used alternately.

### Enabling audio

All videos are muted by default so that they may play on some mobile devices. Please see <a href="#autoplay-support-in-mobile-browsers">autoplay support chart</a>. Enable it by doing the following. 

* Open `slider.php`.
* Locate the following code.

```javascript
var audioAllowed = false;
```

* Change it to the following.

```javascript
var audioAllowed = navigator.userAgent.search("Chrome/") > -1 ? false : true;
```

### Autoplay support 

Please see the <a href="http://tdpedia.thedesignpeople.net/fewd/cyclone-slider-video-autoplay-support-in-mobile-devices/" target="_blank">autoplay support chart</a> on TDPedia.

### Compatibility

* Cyclone Slider 2.10.5 and above

### Issues

Report bugs to this project's issue tracker. Bugs reported elsewhere will not be entertained.