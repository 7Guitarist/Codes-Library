<div id='agentintel_header'>
	<div id='agentintel_ailogo'></div>
	<div id='agentintel_linkssection'>
		<a id='agentintel_supportlink' href='https://www.agentimage.com/ai_support.htm'></a>
		<a id='agentintel_marketinglink' href='https://www.agentimage.com/internet-marketing.htm'></a>
	</div>
</div>
<div style='clear:both;padding-top:10px'></div>
<h2>Latest News from Agent Intelligence</h2>
<?php echo $agentimage_blog_feed; ?>
<div style='clear:both'></div>
<h2>Latest Tweets from Agent Image</h2>
<?php echo $agentimage_twitter_feed; ?>