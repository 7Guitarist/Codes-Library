<style type="text/css">
	#agentintel_ailogo {
		margin-top: 10px;
		width: 250px;
		height: 47px;
		display: block;
		background-image:url('<?php echo $plugin_url ?>/html/images/news-plugin.png');
		background-position: 0 0;
		float:left;
	}
	#agentintel_linkssection {
		float: right;
	}
	#agentintel_supportlink {
		width: 154px;
		height: 44px;
		display: block;
		background-image:url('<?php echo $plugin_url ?>/html/images/news-plugin.png');
		background-position: 0 -48px;
	}
	#agentintel_marketinglink {
		margin-top: -13px;
		width: 154px;
		height: 44px;
		display: block;
		background-image:url('<?php echo $plugin_url ?>/html/images/news-plugin.png');
		background-position: 0 -84px;
	}
	.agentintel_subheaders {
		display: block;
		margin-left: -10px;
		margin-right: 2px;
		width: 100%;
		height: 33px;
		background-image:url('<?php echo $plugin_url ?>/html/images/agentintel_subheader_bk.png');
		background-repeat: repeat-x;
	}
</style>